// notify-server.js
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const notificationapi = require('notificationapi-node-server-sdk').default;
 
notificationapi.init(
  'lwsmrp2tknznx5r2j6vijnghen',
  'aee6jl2m4imlh2uj2l91fpc341gxz8y1gl0xcdr7phxk2gjkm7a5vxpoky'
);
 
const app = express();
app.use(cors());
app.use(bodyParser.json());
 
app.post('/send-notification', async (req, res) => {
  const { email, phoneNumber, fullname } = req.body;
 
  try {
    const response = await notificationapi.send({
      type: 'registration',
      to: {
        id: email,
        email: email,
        number: phoneNumber
      },
      email: {
        subject: '🎉 Welcome to Online Retailer!',
        html: `<h1>Hello ${fullname}</h1><p>Welcome to our platform!</p>`
      },
      sms: {
        message: `Hi ${fullname}, welcome to Online Retailer!`
      }
    });
 
    res.status(200).json({ success: true, data: response.data });
  } catch (err) {
    console.error('Notification error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});
 
app.listen(5000, () => {
  console.log('Notification server running on http://localhost:5000');
});
 
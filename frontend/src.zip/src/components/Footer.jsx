// src/components/Footer.jsx
import React, { useState } from "react";
import { Link } from "react-router-dom";

const footerStyles = {
  container: { display: "flex", gap: 24, alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap" },
  section: { minWidth: 240 },
  linksContainer: { display: "flex", gap: 40, color: "var(--muted)" },
  linkList: { listStyle: "none", padding: 0, margin: 0 }
};

const LinkItem = ({ children, onClick }) => (
  <li>
    <button onClick={onClick} className="footer-link">
      {children}
    </button>
  </li>
);

const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

export default function Footer() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubscribe = async (e) => {
    e?.preventDefault();
    setIsSubmitting(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 800)); // Simulate API call
      
      if (!isValidEmail(email)) {
        setStatus("err");
        return;
      }
      
      setStatus("ok");
      setEmail("");
      setTimeout(() => setStatus(null), 4000);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      handleSubscribe(e);
    }
  };

  return (
    <footer className="site-footer" style={{ marginTop: 48 }}>
      <div className="container" style={footerStyles.container}>
        <div style={footerStyles.section}>
          <strong style={{ display: "block", fontSize: "1.125rem" }}>Online Retail</strong>
          <p className="muted" style={{ marginTop: 8 }}>
            A demo storefront — curated goods with delightful UX.
          </p>
          <div style={{ marginTop: 12 }}>
            <span className="badge">Secure · Fast · Thoughtful</span>
          </div>
        </div>

        <div style={footerStyles.linksContainer}>
          <div>
            <h4 style={{ marginBottom: 8 }}>Company</h4>
            <ul style={footerStyles.linkList}>
              <LinkItem onClick={() => console.log('About')}>About</LinkItem>
              <LinkItem onClick={() => console.log('Careers')}>Careers</LinkItem>
              <LinkItem onClick={() => console.log('Press')}>Press</LinkItem>
            </ul>
          </div>

          <div>
            <h4 style={{ marginBottom: 8 }}>Support</h4>
            <ul style={footerStyles.linkList}>
              <LinkItem onClick={() => console.log('Help')}>Help Center</LinkItem>
              <LinkItem onClick={() => console.log('Returns')}>Returns</LinkItem>
              <LinkItem onClick={() => console.log('Contact')}>Contact</LinkItem>
              <li>
                <Link to="/admin-login" style={{ color: "var(--muted)", textDecoration: "none" }}>
                  Admin Login
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div style={footerStyles.section}>
          <h4 style={{ marginBottom: 8 }}>Stay in touch</h4>
          <form onSubmit={handleSubscribe} style={{ display: "flex", gap: 8 }}>
            <input
              placeholder="Your email"
              value={email}
              onChange={(e) => { setEmail(e.target.value); setStatus(null); }}
              onKeyPress={handleKeyPress}
              aria-label="Subscribe email"
              aria-describedby="subscription-status"
              disabled={isSubmitting}
            />
            <button 
              className="btn btn-primary" 
              type="submit" 
              disabled={isSubmitting}
            >
              {isSubmitting ? "..." : "Subscribe"}
            </button>
          </form>
          <div id="subscription-status" style={{ marginTop: 8, minHeight: 20 }}>
            {status === "ok" && <div className="field-note" style={{ color: "var(--success)" }}>Thanks — we'll keep you posted.</div>}
            {status === "err" && <div className="field-error">Please provide a valid email address.</div>}
          </div>
        </div>
      </div>

      <div style={{ borderTop: "1px solid rgba(15,23,42,0.04)", marginTop: 24, paddingTop: 18, textAlign: "center", color: "var(--muted)" }}>
        <div style={{ maxWidth: 900, margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
          <div>© {new Date().getFullYear()} Online Retail — Demo. All rights reserved.</div>
          <div style={{ display: "flex", gap: 12 }}>
            <LinkItem onClick={() => console.log('Terms')}>Terms</LinkItem>
            <LinkItem onClick={() => console.log('Privacy')}>Privacy</LinkItem>
            <LinkItem onClick={() => console.log('Sitemap')}>Sitemap</LinkItem>
          </div>
        </div>
      </div>
    </footer>
  );
}
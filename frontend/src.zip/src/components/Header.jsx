import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

export default function Header({ onNavigate }) {
  const { user } = useContext(AuthContext);

  return (
    <header className="header">
      <div className="logo" onClick={() => onNavigate("home")}>🛍️ ShopEasy</div>
      <nav>
        {user ? (
          <div
            className="profile-icon"
            onClick={() => onNavigate("profile")}
            style={{
              width: 40,
              height: 40,
              borderRadius: "50%",
              background: "#ef4444",
              color: "#fff",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 700,
              fontSize: 18,
              cursor: "pointer"
            }}
          >
            {user.fullname ? user.fullname[0].toUpperCase() : user.email[0].toUpperCase()}
          </div>
        ) : (
          <button className="btn" onClick={() => onNavigate("login")}>Login</button>
        )}
      </nav>
    </header>
  );
}

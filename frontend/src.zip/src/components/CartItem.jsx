import React, { useState, useEffect } from "react";

export default function CartItem({ item, product, onUpdateQty, onRemove }) {
  const [qty, setQty] = useState(item.quantity || 1);

  useEffect(() => {
    setQty(item.quantity);
  }, [item.quantity]);

  const productId = item.productId;
  const name = product?.name || `Product #${productId}`;
  const description = product?.description?.slice(0, 120) || "No description available.";
  const price = product?.price || item.price || 0;
  const subtotal = (price * qty).toFixed(2);
  const imageUrl = product?.imageURL || product?.imageUrl || `https://dummyimage.com/160x100/cccccc/000000&text=${encodeURIComponent(name)}`;

  function changeQty(next) {
    const n = Math.max(1, Math.floor(Number(next) || 1));
    setQty(n);
    onUpdateQty(productId, n);
  }

  function handleRemoveClick() {
    if (!productId) {
      console.warn("Cannot remove: productId is missing");
      return;
    }
    onRemove(productId);
  }

  return (
    <div className="cart-item" style={{ 
      display: "flex", 
      gap: 16, 
      alignItems: "center", 
      marginBottom: 20, 
      padding: 16, 
      border: "1px solid #eee", 
      borderRadius: 8 
    }}>
      <div className="cart-item-left">
        <img
          src={imageUrl}
          alt={name}
          style={{ width: 80, height: 80, objectFit: "cover", borderRadius: 6 }}
          onError={(e) => {
            e.target.src = "https://dummyimage.com/80x80/cccccc/000000&text=Image";
          }}
        />
      </div>

      <div className="cart-item-body" style={{ flex: 1 }}>
        <h4 style={{ margin: 0, fontSize: 16 }}>{name}</h4>
        <p className="muted" style={{ marginTop: 6, fontSize: 14 }}>{description}</p>

        <div className="cart-item-controls" style={{ marginTop: 10, display: "flex", gap: 12, alignItems: "center" }}>
          <label style={{ display: "inline-flex", gap: 8, alignItems: "center", fontSize: 14 }}>
            Qty:
            <input
              type="number"
              min="1"
              value={qty}
              onChange={(e) => setQty(e.target.value)}
              onBlur={(e) => changeQty(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") changeQty(e.target.value);
              }}
              style={{ width: 60, padding: 4, borderRadius: 4, border: "1px solid #ddd" }}
            />
          </label>

          <button 
            className="btn btn-link" 
            onClick={handleRemoveClick} 
            style={{ padding: "4px 8px", fontSize: 14 }}
          >
            Remove
          </button>
        </div>
      </div>

      <div className="cart-item-right" style={{ textAlign: "right", minWidth: 120 }}>
        <div style={{ fontWeight: 700, fontSize: 16 }}>₹{subtotal}</div>
        <div style={{ fontSize: 12, color: "#777" }}>₹{price.toFixed(2)} each</div>
      </div>
    </div>
  );
}
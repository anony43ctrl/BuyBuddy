// src/components/Pagination.jsx
import React from "react";

/**
 * Pagination
 * - current: current page (1-based)
 * - total: total items
 * - pageSize
 * - onChange(page)
 */
export default function Pagination({ current = 1, total = 0, pageSize = 10, onChange = () => {} }) {
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const pages = [];
  const start = Math.max(1, current - 2);
  const end = Math.min(totalPages, start + 4);
  for (let i = start; i <= end; i++) pages.push(i);

  return (
    <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 12 }}>
      <button className="btn btn-ghost" onClick={() => onChange(1)} disabled={current === 1}>«</button>
      <button className="btn btn-ghost" onClick={() => onChange(current - 1)} disabled={current === 1}>‹</button>
      {pages.map((p) => (
        <button key={p} className={p === current ? "btn btn-primary" : "btn btn-ghost"} onClick={() => onChange(p)}>
          {p}
        </button>
      ))}
      <button className="btn btn-ghost" onClick={() => onChange(current + 1)} disabled={current === totalPages}>›</button>
      <button className="btn btn-ghost" onClick={() => onChange(totalPages)} disabled={current === totalPages}>»</button>
      <div className="muted" style={{ marginLeft: 8 }}>Page {current} of {totalPages}</div>
    </div>
  );
}

// src/components/Toast.jsx
import React, { useEffect } from "react";

export default function Toast({ msg, onClose, timeout = 3500 }) {
  useEffect(() => {
    if (!msg) return;
    const t = setTimeout(() => onClose && onClose(), timeout);
    return () => clearTimeout(t);
  }, [msg, onClose, timeout]);

  if (!msg) return null;
  const isError = msg.type === "error";
  const bg = isError ? "#dc2626" : msg.type === "success" ? "#16a34a" : "#111827";
  return (
    <div style={{
      position: "fixed",
      right: 16,
      bottom: 20,
      background: bg,
      color: "#fff",
      padding: "12px 16px",
      borderRadius: 10,
      boxShadow: "0 8px 24px rgba(16,24,40,0.18)",
      zIndex: 1200,
      minWidth: 240
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center" }}>
        <div style={{ fontWeight: 700 }}>{msg.title || (isError ? "Error" : "Notice")}</div>
        <button onClick={() => onClose && onClose()} style={{ background: "transparent", border: "none", color: "#fff", fontSize: 16 }}>✕</button>
      </div>
      <div style={{ marginTop: 6 }}>{msg.text}</div>
    </div>
  );
}

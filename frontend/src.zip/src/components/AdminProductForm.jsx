
import React, { useEffect, useState } from "react";

/**
 * Simple product form used for create & edit.
 * - initial: optional product (for edit)
 * - onSave(payload): called with ProductCreate-like payload
 * - onCancel()
 */

const CATEGORIES = [
  "ELECTRONICS",
  "CLOTHING",
  "BOOKS",
  "GROCERY",
  "BEAUTY",
  "HOME_APPLIANCE",
];

export default function AdminProductForm({ initial = null, onSave, onCancel, busy = false }) {
  const [name, setName] = useState(initial?.name || "");
  const [description, setDescription] = useState(initial?.description || "");
  const [price, setPrice] = useState(initial?.price ?? 0);
  const [stockQuantity, setStock] = useState(initial?.stockQuantity ?? 0);
  const [category, setCategory] = useState(initial?.category || CATEGORIES[0]);
  // const [sku, setSku] = useState(initial?.sku || "");
  const [active, setActive] = useState(initial?.active ?? true);
  const [imageURL, setImageURL] = useState(initial?.imageUrl || ""); // ✅ NEW: image URL state

  useEffect(() => {
    if (initial) {
      setName(initial.name || "");
      setDescription(initial.description || "");
      setPrice(initial.price ?? 0);
      setStock(initial.stockQuantity ?? 0);
      setCategory(initial.category || CATEGORIES[0]);
      // setSku(initial.sku || "");
      setActive(initial.active ?? true);
      setImageURL(initial.imageURL || ""); // ✅ NEW: image URL initialization
    }
  }, [initial]);

  function handleSubmit(e) {
    e?.preventDefault();
    const payload = {
      name: name.trim(),
      description: description || "",
      price: Number(price) || 0,
      stockQuantity: Number(stockQuantity) || 0,
      category,
      // sku: sku.trim(),
      active: !!active,
      imageURL: imageURL.trim(), // ✅ NEW: include image URL in payload
    };
    onSave?.(payload);
  }

  return (
    <form onSubmit={handleSubmit} style={{ marginTop: 8 }}>
      <label style={{ display: "block", marginBottom: 6, fontWeight: 600 }}>Product name</label>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
        placeholder="e.g. Wireless Headphones"
      />

      <label style={{ display: "block", marginTop: 10, marginBottom: 6, fontWeight: 600 }}>Description</label>
      <textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        rows={4}
        placeholder="Short description for the product"
      />

      <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
        <div style={{ flex: 1 }}>
          <label style={{ display: "block", marginBottom: 6, fontWeight: 600 }}>Price</label>
          <input
            type="number"
            step="0.01"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
          />
        </div>

        <div style={{ width: 140 }}>
          <label style={{ display: "block", marginBottom: 6, fontWeight: 600 }}>Stock</label>
          <input
            type="number"
            value={stockQuantity}
            onChange={(e) => setStock(e.target.value)}
            required
          />
        </div>

        <div style={{ width: 220 }}>
          <label style={{ display: "block", marginBottom: 6, fontWeight: 600 }}>Category</label>
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* <label style={{ display: "block", marginTop: 10, marginBottom: 6, fontWeight: 600 }}>SKU</label>
      <input
        value={sku}
        onChange={(e) => setSku(e.target.value)}
        placeholder="Stock Keeping Unit (optional)"
      /> */}

      {/* ✅ NEW: Image URL input */}
      <label style={{ display: "block", marginTop: 10, marginBottom: 6, fontWeight: 600 }}>Image URL</label>
      <input
        value={imageURL}
        onChange={(e) => setImageURL(e.target.value)}
        placeholder="https://example.com/image.jpg"
      />

      <label style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 10 }}>
        <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} />
        <span>Active</span>
      </label>

      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        <button className="btn btn-primary" type="submit" disabled={busy}>
          {busy ? "Saving…" : "Save"}
        </button>
        <button type="button" className="btn btn-outline" onClick={onCancel} disabled={busy}>
          Cancel
        </button>
      </div>
    </form>
  );
}

// src/components/Navbar.jsx
import React, { useContext, useEffect, useRef, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { cartService } from "../services/cartService";


/**
 * Enhanced Navbar with sophisticated design and animations
 *
 * Features:
 * - Glassmorphism design with backdrop blur
 * - Smooth animations and micro-interactions
 * - Enhanced search with real-time feedback
 * - Floating cart dropdown with smooth transitions
 * - Elegant avatar menu with gradient effects
 * - Modern mobile responsive design
 * - Parallax scroll effects
 *
 * NOTE: Styling and layout preserved from your previous implementation.
 */

const DEBOUNCE_MS = 300;
const CART_POLL_MS = 6000;

export default function Navbar({ onNavigate }) {
  const { user, logout, token } = useContext(AuthContext);

  // state
  const [cartCount, setCartCount] = useState(0);
  const [cartPreview, setCartPreview] = useState(null);
  const [searchText, setSearchText] = useState("");
  const [searchDebounced, setSearchDebounced] = useState("");
  const [searchFocused, setSearchFocused] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [miniCartOpen, setMiniCartOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [loadingCart, setLoadingCart] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // refs
  const avatarRef = useRef(null);
  const miniCartRef = useRef(null);
  const mobileRef = useRef(null);
  const debounceRef = useRef(null);
  const navbarRef = useRef(null);

  // Enhanced scroll effect for navbar background
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setScrolled(scrollPosition > 20);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // fetch cart periodically with enhanced error handling
  useEffect(() => {
  let mounted = true;
  async function fetchCart() {
    if (!user || !user.id || !token) {
      if (mounted) {
        setCartCount(0);
        setCartPreview(null);
      }
      return;
    }
    try {
      setLoadingCart(true);
      const c = await cartService.getCart(user.id, token);
      if (!mounted) return;
      const count = (c?.items || []).reduce((s, it) => s + (it.quantity || 0), 0);
      setCartCount(count);
      setCartPreview(c);
    } catch {
      if (mounted) {
        setCartCount(0);
        setCartPreview(null);
      }
    } finally {
      if (mounted) setLoadingCart(false);
    }
  }
  fetchCart();
  const id = setInterval(fetchCart, CART_POLL_MS);
  return () => {
    mounted = false;
    clearInterval(id);
  };
}, [user, token]);

  // Enhanced debounce search input
  useEffect(() => {
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => setSearchDebounced(searchText.trim()), DEBOUNCE_MS);
    return () => clearTimeout(debounceRef.current);
  }, [searchText]);

  // react to debounced search
  // useEffect(() => {
  //   if (searchDebounced) {
  //     onNavigate?.("products", { q: searchDebounced });
  //   }
  // }, [searchDebounced, onNavigate]);






  // Enhanced outside click handling
  useEffect(() => {
    function onDocClick(e) {
      if (avatarRef.current && !avatarRef.current.contains(e.target)) setMenuOpen(false);
      if (miniCartRef.current && !miniCartRef.current.contains(e.target)) setMiniCartOpen(false);
      if (mobileRef.current && !mobileRef.current.contains(e.target)) setMobileOpen(false);
    }
    function onEsc(e) {
      if (e.key === "Escape") {
        setMenuOpen(false);
        setMiniCartOpen(false);
        setMobileOpen(false);
        setSearchFocused(false);
      }
    }
    document.addEventListener("click", onDocClick);
    document.addEventListener("keydown", onEsc);
    return () => {
      document.removeEventListener("click", onDocClick);
      document.removeEventListener("keydown", onEsc);
    };
  }, []);

  // Enhanced search submit
  // function handleSearchSubmit(e) {
  //   e?.preventDefault();
  //   const q = (searchText || "").trim();
  //   if (!q) onNavigate?.("products");
  //   else onNavigate?.("products", { q });
  //   setSearchFocused(false);
  // }




  function handleSearchSubmit(e) {
  e.preventDefault();
  const q = searchText.trim();
  if (!q) {
    onNavigate?.("products");
  } else {
    onNavigate?.("products", { q });
  }
  setSearchDebounced(q);
  setSearchFocused(false);
}


  // Enhanced avatar initials with better logic
  function avatarInitials() {
    if (!user) return "U";
    if (user.fullname) {
      const parts = user.fullname.split(" ").filter(Boolean);
      if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
      return (parts[0][0] + (parts[parts.length - 1][0] || "")).toUpperCase();
    }
    if (user.email) return user.email.slice(0, 2).toUpperCase();
    return "U";
  }

  // Enhanced logout with animation
  async function handleLogout() {
    try {
      logout?.();
      setMenuOpen(false);
      onNavigate?.("login");
    } catch {
      // ignore
    }
  }

  // Enhanced cart navigation
  function openCart() {
    setMiniCartOpen(false);
    onNavigate?.("cart");
  }

  function handleCheckout() {
    setMiniCartOpen(false);
    onNavigate?.("cart");
  }

  // Enhanced MiniCart with sophisticated design
  function MiniCart() {
    const items = cartPreview?.items || [];

    const cartStyle = {
      width: 420,
      background: "rgba(255, 255, 255, 0.95)",
      backdropFilter: "blur(20px)",
      border: "1px solid rgba(255, 255, 255, 0.2)",
      borderRadius: 24,
      boxShadow: "0 32px 128px rgba(0, 0, 0, 0.2)",
      padding: 28,
      animation: "slideDownFade 0.3s cubic-bezier(0.4, 0, 0.2, 1) both",
      position: "relative",
      overflow: "hidden"
    };

    // Gradient overlay for depth
    const overlayStyle = {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: "linear-gradient(135deg, rgba(var(--brand-rgb), 0.02), rgba(var(--brand-2-rgb), 0.01))",
      zIndex: -1
    };

    // if guest
    if (!user) {
      return (
        <div style={cartStyle}>
          <div style={overlayStyle} />
          <div style={{ 
            fontWeight: 800, 
            fontSize: 20, 
            marginBottom: 12,
            background: "linear-gradient(135deg, var(--text), var(--muted))",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent"
          }}>
            Your cart
          </div>
          <div className="muted" style={{ 
            marginBottom: 24, 
            fontSize: 15,
            lineHeight: 1.5
          }}>
            Sign in to view your cart items and start shopping.
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            <button 
              className="btn btn-primary" 
              onClick={() => onNavigate?.("login")}
              style={{
                flex: 1,
                background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                fontWeight: 600,
                padding: "12px 20px"
              }}
            >
              Sign in
            </button>
            <button 
              className="btn btn-outline" 
              onClick={() => onNavigate?.("register")}
              style={{
                flex: 1,
                fontWeight: 600,
                padding: "12px 20px"
              }}
            >
              Create account
            </button>
          </div>
        </div>
      );
    }

    // loading state
    if (loadingCart) {
      return (
        <div style={cartStyle}>
          <div style={overlayStyle} />
          <div style={{ 
            display: "flex", 
            alignItems: "center", 
            gap: 16,
            justifyContent: "center",
            padding: "20px 0"
          }}>
            <div style={{
              width: 24,
              height: 24,
              border: "2px solid var(--border)",
              borderTop: "2px solid var(--brand)",
              borderRadius: "50%",
              animation: "spin 1s linear infinite"
            }} />
            <div style={{ fontWeight: 600, color: "var(--muted)" }}>Loading your cart…</div>
          </div>
        </div>
      );
    }

    // empty
    if (!items.length) {
      return (
        <div style={cartStyle}>
          <div style={overlayStyle} />
          <div style={{ textAlign: "center" }}>
            <div style={{
              width: 64,
              height: 64,
              borderRadius: "50%",
              background: "linear-gradient(135deg, rgba(var(--brand-rgb), 0.1), rgba(var(--brand-2-rgb), 0.05))",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 16px"
            }}>
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                <path d="M6 6h15l-1.6 8H8.6L6 6z" stroke="var(--brand)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                <circle cx="10" cy="19" r="1" fill="var(--brand)" />
                <circle cx="18" cy="19" r="1" fill="var(--brand)" />
              </svg>
            </div>
            <div style={{ fontWeight: 800, fontSize: 18, marginBottom: 8 }}>Your cart is empty</div>
            <div className="muted" style={{ marginBottom: 20, fontSize: 15 }}>
              Discover amazing products and add them to your cart.
            </div>
            <button 
              className="btn btn-primary" 
              onClick={() => { onNavigate?.("products"); setMiniCartOpen(false); }}
              style={{
                background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                fontWeight: 600,
                padding: "12px 24px"
              }}
            >
              Start shopping
            </button>
          </div>
        </div>
      );
    }

    // non-empty: show items with enhanced design
    const first = items.slice(0, 3);
    const subtotal = items.reduce((s, it) => s + ((it.quantity || 0) * (it.price || 0)), 0);

    return (
      <div style={cartStyle}>
        <div style={overlayStyle} />
        
        {/* Header */}
        <div style={{ 
          display: "flex", 
          justifyContent: "space-between", 
          alignItems: "center",
          marginBottom: 20
        }}>
          <div style={{ 
            fontWeight: 800, 
            fontSize: 20,
            background: "linear-gradient(135deg, var(--text), var(--muted))",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent"
          }}>
            Shopping Cart
          </div>
          <div style={{
            background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
            color: "#fff",
            padding: "6px 12px",
            borderRadius: 20,
            fontSize: 12,
            fontWeight: 700
          }}>
            {items.length} {items.length === 1 ? 'item' : 'items'}
          </div>
        </div>

        {/* Items */}
        <div style={{ marginBottom: 20 }}>
          {first.map((it, index) => (
            <div 
              key={it.id} 
              style={{ 
                display: "flex", 
                gap: 16, 
                alignItems: "center",
                padding: "12px 0",
                borderBottom: index < first.length - 1 ? "1px solid var(--border)" : "none",
                animation: `fadeInUp 0.3s cubic-bezier(0.4, 0, 0.2, 1) ${index * 100}ms both`
              }}
            >
              <div style={{
                width: 64,
                height: 64,
                borderRadius: 12,
                overflow: "hidden",
                background: "linear-gradient(135deg, #f3f4f6, #e5e7eb)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0
              }}>
                <img
                  src={`https://via.placeholder.com/128x128?text=${encodeURIComponent(it.product_id)}`}
                  alt=""
                  style={{ 
                    width: "100%", 
                    height: "100%", 
                    objectFit: "cover"
                  }}
                />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ 
                  fontWeight: 700, 
                  fontSize: 15,
                  marginBottom: 4,
                  color: "var(--text)"
                }}>
                  {it.product_id ? `Product #${it.product_id}` : "Item"}
                </div>
                <div style={{ 
                  display: "flex", 
                  alignItems: "center", 
                  gap: 12,
                  fontSize: 13
                }}>
                  <span className="muted">Qty {it.quantity}</span>
                  <span style={{
                    background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    fontWeight: 700
                  }}>
                    ₹{(it.price || 0).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          ))}

          {items.length > 3 && (
            <div style={{ 
              textAlign: "center", 
              padding: "12px 0",
              color: "var(--muted)",
              fontSize: 14,
              fontWeight: 500
            }}>
              +{items.length - 3} more items
            </div>
          )}
        </div>

        {/* Subtotal */}
        <div style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "16px 0",
          borderTop: "2px solid var(--border)",
          marginBottom: 20
        }}>
          <div style={{ fontWeight: 600, fontSize: 16 }}>Subtotal</div>
          <div style={{
            fontWeight: 800,
            fontSize: 18,
            background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent"
          }}>
            ₹{(subtotal || 0).toFixed(2)}
          </div>
        </div>

        {/* Actions */}
        <div style={{ display: "flex", gap: 12 }}>
          <button 
            className="btn btn-outline" 
            onClick={openCart} 
            style={{ 
              flex: 1,
              fontWeight: 600,
              padding: "12px"
            }}
          >
            View cart
          </button>
          <button 
            className="btn btn-primary" 
            onClick={handleCheckout} 
            style={{ 
              flex: 1,
              background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
              fontWeight: 600,
              padding: "12px"
            }}
          >
            Checkout
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      <header 
        ref={navbarRef}
        className="nav" 
        role="banner" 
        aria-label="Primary navigation"
        style={{
          background: scrolled 
            ? "rgba(255, 255, 255, 0.95)" 
            : "transparent",
          backdropFilter: "blur(20px)",
          borderBottom: scrolled 
            ? "1px solid rgba(0, 0, 0, 0.08)" 
            : "1px solid rgba(255, 255, 255, 0.0)",
          transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
          position: "sticky",
          top: 0,
          zIndex: 1000,
          boxShadow: scrolled 
            ? "0 8px 32px rgba(0, 0, 0, 0.12)" 
            : "0 4px 16px rgba(0, 0, 0, 0.04)"
        }}
      >
        {/* LEFT: Enhanced brand + primary links */}
        <div className="nav-left" style={{ gap: 16, alignItems: "center" }}>
          <button
            className="nav-brand"
            onClick={() => { onNavigate?.("home"); setSearchText(""); }}
            aria-label="Go to home"
            style={{
              display: "flex",
              alignItems: "center",
              gap: 12,
              padding: "8px 12px",
              borderRadius: 16,
              transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
              background: "transparent"
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = "rgba(255, 255, 255, 0.1)";
              e.currentTarget.style.transform = "scale(1.02)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = "transparent";
              e.currentTarget.style.transform = "scale(1)";
            }}
          >
            <div className="brand-tile" style={{ 
              width: 36,
              height: 36,
              borderRadius: 10,
              background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 4px 16px rgba(var(--brand-rgb), 0.3)"
            }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <rect width="24" height="24" rx="5" fill="#fff" opacity="0.9" />
                <path d="M7 13h10L17 7H7v6z" fill="var(--brand)" />
              </svg>
            </div>

            <div style={{ textAlign: "left" }}>
              <div style={{ 
                fontWeight: 800, 
                color: scrolled ? "var(--text)" : "var(--text)", 
                fontSize: 18,
                lineHeight: 1
              }}>
                Online Retail
              </div>
              <div className="kicker" style={{ 
                marginTop: 2, 
                fontWeight: 500,
                fontSize: 11,
                color: scrolled ? "var(--muted)" : "var(--muted)",
                letterSpacing: "0.5px"
              }}>
                clean · curated · delightful
              </div>
            </div>
          </button>

          <nav aria-label="Main" style={{ display: "flex", gap: 8 }}>
            <button 
              className="nav-link" 
              onClick={() => onNavigate?.("products")}
              style={{
                color: scrolled ? "var(--text)" : "var(--text)",
                fontWeight: 600,
                padding: "8px 16px",
                borderRadius: 12,
                transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = scrolled 
                  ? "rgba(var(--brand-rgb), 0.1)" 
                  : "rgba(0, 0, 0, 0.04)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "transparent";
              }}
            >
              Products
            </button>
            <button 
              className="nav-link" 
              onClick={() => onNavigate?.("home")}
              style={{
                color: scrolled ? "var(--text)" : "var(--text)",
                fontWeight: 600,
                padding: "8px 16px",
                borderRadius: 12,
                transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = scrolled 
                  ? "rgba(var(--brand-rgb), 0.1)" 
                  : "rgba(0, 0, 0, 0.04)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "transparent";
              }}
            >
              Collections
            </button>
          </nav>
        </div>

        {/* CENTER: Enhanced search */}
        <div style={{ 
          flex: 1, 
          display: "flex", 
          justifyContent: "center",
          maxWidth: 600,
          margin: "0 32px"
        }}>
          <form 
            onSubmit={handleSearchSubmit} 
            style={{ 
              width: "100%",
              position: "relative"
            }}
          >
            <div style={{ 
              display: "flex", 
              gap: 8, 
              alignItems: "center",
              background: searchFocused 
                ? "rgba(255, 255, 255, 0.95)" 
                : scrolled 
                  ? "rgba(255, 255, 255, 0.8)" 
                  : "rgba(255, 255, 255, 0.1)",
              borderRadius: 16,
              border: searchFocused 
                ? "2px solid var(--brand)" 
                : scrolled 
                  ? "1px solid rgba(0, 0, 0, 0.1)" 
                  : "1px solid rgba(255, 255, 255, 0.2)",
              transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
              backdropFilter: "blur(20px)",
              padding: "4px"
            }}>
              <input
                className="search-input"
                placeholder="Search products, categories, brands..."
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                onBlur={() => setTimeout(() => setSearchFocused(false), 150)}
                aria-label="Search products"
                style={{
                  background: "transparent",
                  border: "none",
                  flex: 1,
                  padding: "12px 16px",
                  color: "var(--text)",
                  fontSize: 15,
                  fontWeight: 500
                }}
              />
              
              <button 
                type="submit" 
                className="btn btn-primary" 
                aria-label="Search"
                style={{
                  background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                  border: "none",
                  padding: "10px 20px",
                  borderRadius: 12,
                  fontWeight: 600,
                  fontSize: 14,
                  boxShadow: "0 2px 8px rgba(var(--brand-rgb), 0.3)",
                  transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-1px)";
                  e.currentTarget.style.boxShadow = "0 4px 12px rgba(var(--brand-rgb), 0.4)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.boxShadow = "0 2px 8px rgba(var(--brand-rgb), 0.3)";
                }}
              >
                Search
              </button>

              {searchText && (
                <button
                  type="button"
                  className="btn-clear"
                  title="Clear search"
                  onClick={() => {
                    setSearchText("");
                    setSearchDebounced("");
                    onNavigate?.("products");
                  }}
                  style={{
                    background: "rgba(var(--muted-rgb), 0.1)",
                    border: "none",
                    padding: "8px 12px",
                    borderRadius: 8,
                    color: "var(--muted)",
                    fontSize: 12,
                    fontWeight: 500,
                    transition: "all 0.2s ease",
                    cursor: "pointer"
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = "rgba(var(--danger-rgb), 0.1)";
                    e.currentTarget.style.color = "var(--danger)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = "rgba(var(--muted-rgb), 0.1)";
                    e.currentTarget.style.color = "var(--muted)";
                  }}
                >
                  Clear
                </button>
              )}
            </div>

            {/* Search suggestions overlay */}
            {searchFocused && searchText && (
              <div style={{
                position: "absolute",
                top: "100%",
                left: 0,
                right: 0,
                marginTop: 8,
                background: "rgba(255, 255, 255, 0.95)",
                backdropFilter: "blur(20px)",
                border: "1px solid rgba(255, 255, 255, 0.2)",
                borderRadius: 16,
                boxShadow: "0 16px 64px rgba(0, 0, 0, 0.15)",
                padding: 16,
                zIndex: 1100,
                animation: "slideDownFade 0.2s cubic-bezier(0.4, 0, 0.2, 1) both"
              }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: "var(--muted)", marginBottom: 8 }}>
                  SEARCHING FOR "{searchText}"
                </div>
                <div style={{ fontSize: 14, color: "var(--text)" }}>
                  Press Enter to search products
                </div>
              </div>
            )}
          </form>
        </div>

        {/* RIGHT: Enhanced utilities */}
        <div className="nav-right" style={{ gap: 16, alignItems: "center" }}>
          <button 
            className="nav-link" 
            onClick={() => onNavigate?.("products")}
            style={{
              color: scrolled ? "var(--text)" : "var(--text)",
              fontWeight: 600,
              padding: "8px 16px",
              borderRadius: 12,
              transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = scrolled 
                ? "rgba(var(--brand-rgb), 0.1)" 
                : "rgba(0, 0, 0, 0.04)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = "transparent";
            }}
          >
            Browse
          </button>

          {/* Enhanced Cart button */}
          <div style={{ position: "relative" }} ref={miniCartRef}>
            <button
              className="nav-link"
              onClick={() => setMiniCartOpen((s) => !s)}
              aria-haspopup="dialog"
              aria-expanded={miniCartOpen}
              aria-label={`Cart (${cartCount} items)`}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                padding: "8px 16px",
                borderRadius: 12,
                background: miniCartOpen 
                  ? "rgba(var(--brand-rgb), 0.1)" 
                  : "transparent",
                border: miniCartOpen 
                  ? "1px solid rgba(var(--brand-rgb), 0.2)" 
                  : "1px solid transparent",
                transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                color: scrolled ? "var(--text)" : "var(--text)",
                position: "relative"
              }}
              onMouseEnter={(e) => {
                if (!miniCartOpen) {
                  e.currentTarget.style.background = scrolled 
                    ? "rgba(var(--brand-rgb), 0.1)" 
                    : "rgba(0, 0, 0, 0.04)";
                }
              }}
              onMouseLeave={(e) => {
                if (!miniCartOpen) {
                  e.currentTarget.style.background = "transparent";
                }
              }}
            >
              <div style={{ position: "relative" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path d="M6 6h15l-1.6 8H8.6L6 6z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  <circle cx="10" cy="19" r="1" fill="currentColor" />
                  <circle cx="18" cy="19" r="1" fill="currentColor" />
                </svg>
                
                {/* Animated cart badge */}
                {cartCount > 0 && (
                  <div style={{
                    position: "absolute",
                    top: -8,
                    right: -8,
                    width: 20,
                    height: 20,
                    background: "linear-gradient(135deg, #ef4444, #dc2626)",
                    color: "#fff",
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 10,
                    fontWeight: 700,
                    animation: cartCount > 0 ? "bounce 0.5s ease both" : "none",
                    boxShadow: "0 2px 8px rgba(239, 68, 68, 0.3)"
                  }}>
                    {cartCount > 99 ? '99+' : cartCount}
                  </div>
                )}
              </div>

              <span style={{ 
                fontWeight: 600,
                fontSize: 14
              }}>
                Cart
              </span>
            </button>

            {/* Enhanced Mini Cart Dropdown */}
            {miniCartOpen && (
              <div style={{ 
                position: "absolute", 
                right: 0, 
                top: "calc(100% + 8px)", 
                zIndex: 1200
              }}>
                <MiniCart />
              </div>
            )}
          </div>

          {/* Enhanced User area */}
          {user ? (
            <div
  ref={avatarRef}
  className="avatar-menu"
  onClick={() => onNavigate?.("profile")}
  style={{ cursor: "pointer" }}
>

              <button
                className="avatar"
                onClick={() => setMenuOpen((s) => !s)}
                aria-haspopup="menu"
                aria-expanded={menuOpen}
                aria-label="Open user menu"
                title={user.fullname || user.email}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: "50%",
                  background: menuOpen 
                    ? "linear-gradient(135deg, var(--brand), var(--brand-2))"
                    : "linear-gradient(135deg, var(--brand), var(--brand-2))",
                  color: "#fff",
                  border: "2px solid rgba(255, 255, 255, 0.2)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontWeight: 700,
                  fontSize: 14,
                  cursor: "pointer",
                  transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                  boxShadow: "0 4px 16px rgba(0, 0, 0, 0.15)",
                  position: "relative",
                  overflow: "hidden"
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "scale(1.05)";
                  e.currentTarget.style.boxShadow = "0 8px 24px rgba(0, 0, 0, 0.25)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "scale(1)";
                  e.currentTarget.style.boxShadow = "0 4px 16px rgba(0, 0, 0, 0.15)";
                }}
              >
                {/* Avatar background effect */}
                <div style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  background: "linear-gradient(135deg, rgba(255,255,255,0.1), transparent)",
                  zIndex: 0
                }} />
                
                <span style={{ position: "relative", zIndex: 1 }}>
                  {avatarInitials()}
                </span>

                {/* Online indicator */}
                <div style={{
                  position: "absolute",
                  bottom: 2,
                  right: 2,
                  width: 10,
                  height: 10,
                  background: "#10b981",
                  borderRadius: "50%",
                  border: "2px solid #fff",
                  animation: "pulse 2s ease-in-out infinite"
                }} />
              </button>
              {menuOpen && (
  <div
    style={{
      position: "absolute",
      top: "calc(100% + 8px)",
      right: 0,
      background: "#fff",
      borderRadius: 12,
      boxShadow: "0 8px 24px rgba(0,0,0,0.15)",
      padding: "12px 0",
      zIndex: 10,
      minWidth: 160
    }}
  >
    <button
      className="dropdown-item"
      onClick={() => {
        setMenuOpen(false);
        onNavigate?.("profile");
      }}
      style={{
        width: "100%",
        padding: "10px 16px",
        textAlign: "left",
        background: "none",
        border: "none",
        fontSize: 14,
        cursor: "pointer"
      }}
    >
      Profile
    </button>
   
    <button
      className="dropdown-item"
      onClick={() => {
        logout?.();
        setMenuOpen(false);
        onNavigate?.("login");
      }}
      style={{
        width: "100%",
        padding: "10px 16px",
        textAlign: "left",
        background: "none",
        border: "none",
        fontSize: 14,
        cursor: "pointer",
        color: "#ef4444"
      }}
    >
      Logout
    </button>
  </div>
)}


              {/* Enhanced User Menu (includes admin links when applicable) */}
              {menuOpen && (
                <div 
                  className="menu-list" 
                  role="menu" 
                  style={{ 
                    position: "absolute",
                    right: 0, 
                    top: "calc(100% + 8px)",
                    width: 240,
                    background: "rgba(255, 255, 255, 0.95)",
                    backdropFilter: "blur(20px)",
                    border: "1px solid rgba(255, 255, 255, 0.2)",
                    borderRadius: 16,
                    boxShadow: "0 20px 64px rgba(0, 0, 0, 0.2)",
                    padding: 8,
                    animation: "slideDownFade 0.2s cubic-bezier(0.4, 0, 0.2, 1) both",
                    zIndex: 1200
                  }}
                >
                  {/* User info header */}
                  <div style={{
                    padding: "12px 16px",
                    borderBottom: "1px solid var(--border)",
                    marginBottom: 8
                  }}>
                    <div style={{ 
                      fontWeight: 700, 
                      color: "var(--text)",
                      fontSize: 14,
                      marginBottom: 2
                    }}>
                      {user.fullname || "User"}
                    </div>
                    <div style={{ 
                      color: "var(--muted)", 
                      fontSize: 12 
                    }}>
                      {user.email}
                    </div>
                  </div>

                  {/* Menu items */}
                  <button 
                    role="menuitem" 
                    onClick={() => { setMenuOpen(false); onNavigate?.("profile"); }}
                    style={menuItemStyle}
                    onMouseEnter={(e) => styleHover(e)}
                    onMouseLeave={(e) => styleLeave(e)}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ marginRight: 8 }}>
                      <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.5"/>
                    </svg>
                    Profile
                  </button>

                  <button 
                    role="menuitem" 
                    onClick={() => { setMenuOpen(false); onNavigate?.("orders"); }}
                    style={menuItemStyle}
                    onMouseEnter={(e) => styleHover(e)}
                    onMouseLeave={(e) => styleLeave(e)}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ marginRight: 8 }}>
                      <rect x="3" y="4" width="18" height="16" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                      <path d="M8 8h8m-8 4h6" stroke="currentColor" strokeWidth="1.5"/>
                    </svg>
                    Orders
                  </button>

                  <button 
                    role="menuitem" 
                    onClick={() => { setMenuOpen(false); onNavigate?.("updatePassword"); }}
                    style={menuItemStyle}
                    onMouseEnter={(e) => styleHover(e)}
                    onMouseLeave={(e) => styleLeave(e)}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ marginRight: 8 }}>
                      <rect x="3" y="11" width="18" height="11" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                      <path d="M7 11V7a5 5 0 0110 0v4" stroke="currentColor" strokeWidth="1.5"/>
                    </svg>
                    Change password
                  </button>

                  {/* Admin links (only visible to admins) */}
                  {user?.role === "ADMIN" && (
  <>
    <div style={{ height: 1, background: "var(--border)", margin: "8px 0" }} />
    
    <button
      role="menuitem"
      onClick={() => { setMenuOpen(false); onNavigate?.("adminDashboard"); }}
      style={menuItemStyle}
      onMouseEnter={(e) => styleHover(e)}
      onMouseLeave={(e) => styleLeave(e)}
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ marginRight: 8 }}>
        <path d="M3 13h8V3H3v10zM13 21h8V11h-8v10zM13 3v6h8V3h-8z" stroke="currentColor" strokeWidth="1.3"></path>
      </svg>
      Admin Dashboard
    </button>

    <button
      role="menuitem"
      onClick={() => { setMenuOpen(false); onNavigate?.("adminProducts"); }}
      style={menuItemStyle}
      onMouseEnter={(e) => styleHover(e)}
      onMouseLeave={(e) => styleLeave(e)}
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ marginRight: 8 }}>
        <rect x="3" y="3" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="1.5"/>
        <rect x="14" y="3" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="1.5"/>
        <rect x="14" y="14" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="1.5"/>
        <rect x="3" y="14" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="1.5"/>
      </svg>
      Manage Products
    </button>

    <button
      role="menuitem"
      onClick={() => { setMenuOpen(false); onNavigate?.("adminOrders"); }}
      style={menuItemStyle}
      onMouseEnter={(e) => styleHover(e)}
      onMouseLeave={(e) => styleLeave(e)}
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ marginRight: 8 }}>
        <path d="M3 10h18M7 15h1m4 0h1m-6 4h12a2 2 0 002-2V8a2 2 0 00-2-2H7a2 2 0 00-2 2v9a2 2 0 002 2z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
      Manage Orders
    </button>

    <button
      role="menuitem"
      onClick={() => { setMenuOpen(false); onNavigate?.("adminUsers"); }}
      style={menuItemStyle}
      onMouseEnter={(e) => styleHover(e)}
      onMouseLeave={(e) => styleLeave(e)}
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ marginRight: 8 }}>
        <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <circle cx="9" cy="7" r="4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M23 21v-2a4 4 0 00-3-3.87m-4-12a4 4 0 010 7.75" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
      Manage Users
    </button>
  </>
)}

                  <div style={{ 
                    height: 1, 
                    background: "var(--border)", 
                    margin: "8px 16px" 
                  }} />

                  <button 
                    role="menuitem" 
                    onClick={() => handleLogout()}
                    style={{
                      width: "100%",
                      padding: "10px 16px",
                      borderRadius: 8,
                      border: "none",
                      background: "transparent",
                      color: "var(--danger)",
                      fontSize: 14,
                      fontWeight: 500,
                      textAlign: "left",
                      cursor: "pointer",
                      transition: "all 0.2s ease",
                      display: "flex",
                      alignItems: "center",
                      gap: 10
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = "rgba(var(--danger-rgb), 0.1)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = "transparent";
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ marginRight: 8 }}>
                      <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4m7 14l5-5-5-5m5 5H9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                    Logout
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* Enhanced Auth buttons */
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <button 
                className="nav-link" 
                onClick={() => onNavigate?.("login")}
                style={{
                  color: scrolled ? "var(--text)" : "var(--text)",
                  fontWeight: 600,
                  padding: "8px 16px",
                  borderRadius: 12,
                  transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = scrolled 
                    ? "rgba(var(--brand-rgb), 0.1)" 
                    : "rgba(0, 0, 0, 0.04)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "transparent";
                }}
              >
                Sign in
              </button>
              <button 
                className="nav-cta" 
                onClick={() => onNavigate?.("register")}
                style={{
                  background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                  color: "#fff",
                  padding: "10px 20px",
                  borderRadius: 12,
                  border: "none",
                  fontWeight: 600,
                  fontSize: 14,
                  cursor: "pointer",
                  transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                  boxShadow: "0 4px 16px rgba(var(--brand-rgb), 0.3)"
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-2px)";
                  e.currentTarget.style.boxShadow = "0 8px 24px rgba(var(--brand-rgb), 0.4)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.boxShadow = "0 4px 16px rgba(var(--brand-rgb), 0.3)";
                }}
              >
                Sign up
              </button>
            </div>
          )}

          {/* Enhanced Mobile hamburger */}
          <div ref={mobileRef} className="mobile-toggle" style={{ display: "none" }}>
            <button 
              className="btn" 
              aria-label="Toggle menu" 
              onClick={() => setMobileOpen((s) => !s)}
              style={{
                padding: "8px",
                borderRadius: 8,
                background: mobileOpen ? "rgba(var(--brand-rgb), 0.1)" : "transparent",
                border: "1px solid rgba(255, 255, 255, 0.2)",
                color: scrolled ? "var(--text)" : "var(--text)",
                transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
              }}
            >
              <svg 
                width="18" 
                height="18" 
                viewBox="0 0 24 24" 
                fill="none"
                style={{
                  transform: mobileOpen ? "rotate(90deg)" : "rotate(0deg)",
                  transition: "transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                }}
              >
                <path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>

            {/* Enhanced Mobile menu */}
            {mobileOpen && (
              <div style={{ 
                position: "absolute", 
                right: 8, 
                top: "calc(100% + 8px)", 
                width: 280, 
                zIndex: 1200,
                background: "rgba(255, 255, 255, 0.95)",
                backdropFilter: "blur(20px)",
                border: "1px solid rgba(255, 255, 255, 0.2)",
                borderRadius: 16,
                boxShadow: "0 20px 64px rgba(0, 0, 0, 0.2)",
                padding: 16,
                animation: "slideDownFade 0.2s cubic-bezier(0.4, 0, 0.2, 1) both"
              }}>
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                  <button 
                    className="nav-link" 
                    onClick={() => { setMobileOpen(false); onNavigate?.("products"); }}
                    style={mobileMenuItemStyle}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(var(--brand-rgb), 0.1)")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                  >
                    Products
                  </button>
                  
                  <button 
                    className="nav-link" 
                    onClick={() => { setMobileOpen(false); onNavigate?.("cart"); }}
                    style={mobileMenuItemStyle}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(var(--brand-rgb), 0.1)")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                  >
                    Cart
                    {cartCount > 0 && (
                      <span style={{
                        background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                        color: "#fff",
                        padding: "2px 8px",
                        borderRadius: 12,
                        fontSize: 12,
                        fontWeight: 700
                      }}>
                        {cartCount}
                      </span>
                    )}
                  </button>
                  
                  {user ? (
                    <>
                      <div style={{ height: 1, background: "var(--border)", margin: "8px 0" }} />
                      <button 
                        className="nav-link" 
                        onClick={() => { setMobileOpen(false); onNavigate?.("profile"); }}
                        style={mobileMenuItemStyle}
                      >
                        Profile
                      </button>
                      <button 
                        className="nav-link" 
                        onClick={() => { setMobileOpen(false); handleLogout(); }}
                        style={{ ...mobileMenuItemStyle, color: "var(--danger)" }}
                        onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(var(--danger-rgb), 0.1)")}
                        onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                      >
                        Logout
                      </button>
                    </>
                  ) : (
                    <>
                      <div style={{ height: 1, background: "var(--border)", margin: "8px 0" }} />
                      <button 
                        className="nav-link" 
                        onClick={() => { setMobileOpen(false); onNavigate?.("login"); }}
                        style={mobileMenuItemStyle}
                      >
                        Sign in
                      </button>
                      <button 
                        className="nav-cta" 
                        onClick={() => { setMobileOpen(false); onNavigate?.("register"); }}
                        style={{
                          background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                          color: "#fff",
                          padding: "12px 16px",
                          borderRadius: 8,
                          border: "none",
                          fontWeight: 600,
                          fontSize: 15,
                          textAlign: "left",
                          cursor: "pointer",
                          transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                        }}
                      >
                        Sign up
                      </button>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Enhanced CSS animations */}
      <style>{`
        @keyframes slideDownFade {
          from {
            opacity: 0;
            transform: translateY(-10px) scale(0.95);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
        
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes bounce {
          0%, 20%, 53%, 80%, 100% {
            transform: translate3d(0, 0, 0);
          }
          40%, 43% {
            transform: translate3d(0, -8px, 0);
          }
          70% {
            transform: translate3d(0, -4px, 0);
          }
          90% {
            transform: translate3d(0, -2px, 0);
          }
        }
        
        @keyframes pulse {
          0%, 100% {
            opacity: 1;
            transform: scale(1);
          }
          50% {
            opacity: 0.8;
            transform: scale(1.05);
          }
        }
        
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        
        /* Enhanced responsive design */
        @media (max-width: 768px) {
          .nav-left nav,
          .nav-right > .nav-link:not(:last-child) {
            display: none;
          }
          
          .mobile-toggle {
            display: block !important;
          }
        }
      `}</style>
    </>
  );
}

/* Helper styles used inline to reduce duplication */
const menuItemStyle = {
  width: "100%",
  padding: "10px 16px",
  borderRadius: 8,
  border: "none",
  background: "transparent",
  color: "var(--text)",
  fontSize: 14,
  fontWeight: 500,
  textAlign: "left",
  cursor: "pointer",
  transition: "all 0.2s ease",
  display: "flex",
  alignItems: "center",
  gap: 10
};

function styleHover(e) {
  e.currentTarget.style.background = "rgba(var(--brand-rgb), 0.1)";
  e.currentTarget.style.color = "var(--brand)";
}
function styleLeave(e) {
  e.currentTarget.style.background = "transparent";
  e.currentTarget.style.color = "var(--text)";
}

const mobileMenuItemStyle = {
  textAlign: "left",
  padding: "12px 16px",
  borderRadius: 8,
  background: "transparent",
  border: "none",
  color: "var(--text)",
  fontWeight: 500,
  fontSize: 15,
  transition: "all 0.2s ease",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between"
};

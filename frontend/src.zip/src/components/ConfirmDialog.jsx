// src/components/ConfirmDialog.jsx
import React from "react";
import Modal from "./Modal";

/**
 * ConfirmDialog
 * props:
 *  - open (bool)
 *  - title
 *  - message
 *  - onConfirm()
 *  - onCancel()
 *  - confirmText / cancelText
 */
export default function ConfirmDialog({ open, title = "Confirm", message, onConfirm, onCancel, confirmText = "Yes", cancelText = "Cancel" }) {
  if (!open) return null;
  return (
    <Modal title={title} onClose={onCancel}>
      <div style={{ marginBottom: 16 }}>{message}</div>
      <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
        <button className="btn btn-outline" onClick={onCancel}>{cancelText}</button>
        <button className="btn btn-danger" onClick={onConfirm}>{confirmText}</button>
      </div>
    </Modal>
  );
}

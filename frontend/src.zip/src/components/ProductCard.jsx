import React from "react";

export default function ProductCard({ product, onView, onAddToCart }) {
  const handleAddToCart = (e) => {
    e.stopPropagation();
    onAddToCart(product.id);
  };

  const handleView = (e) => {
    e.stopPropagation();
    onView(product.id);
  };

  return (
    <article 
      className="product-card" 
      style={{ 
        transition: "transform .12s ease, box-shadow .12s ease",
        border: "1px solid #eee",
        borderRadius: 8,
        overflow: "hidden",
        background: "#fff",
        cursor: "pointer"
      }}
      onClick={handleView}
    >
      <div style={{ position: "relative" }}>
        <img
          src={product.imageURL || `https://dummyimage.com/300x200/cccccc/000000&text=${encodeURIComponent(product.name || "Product")}`}
          alt={product.name}
          style={{ width: "100%", height: 200, objectFit: "cover" }}
          onError={(e) => {
            e.target.src = "https://dummyimage.com/300x200/cccccc/000000&text=Product+Image";
          }}
        />
        {product.stockQuantity <= 0 && (
          <span style={{
            position: "absolute", 
            left: 8, 
            top: 8, 
            background: "#ef4444", 
            color: "#fff", 
            padding: "4px 8px",
            borderRadius: 4, 
            fontSize: 12, 
            fontWeight: 700
          }}>
            Out of stock
          </span>
        )}
      </div>

      <div className="product-body" style={{ padding: 12 }}>
        <h3 className="product-title" style={{ fontSize: 16, margin: "0 0 8px 0" }}>{product.name}</h3>
        <p className="product-desc" style={{ fontSize: 13, color: "#555", margin: "0 0 12px 0" }}>
          {product.description ? product.description.slice(0, 120) + (product.description.length > 120 ? "…" : "") : "No description available"}
        </p>

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 18 }}>₹{product.price?.toFixed(2) || "0.00"}</div>
            <div style={{ fontSize: 12, color: "#777" }}>{product.category}</div>
          </div>

          <div style={{ display: "flex", gap: 8 }}>
            <button 
              className="btn" 
              onClick={handleView}
              style={{ padding: "6px 12px", fontSize: 12 }}
            >
              View
            </button>
            <button 
              className="btn btn-outline" 
              disabled={product.stockQuantity <= 0} 
              onClick={handleAddToCart}
              style={{ padding: "6px 12px", fontSize: 12 }}
            >
              Add
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}
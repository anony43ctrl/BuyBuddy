// src/components/Modal.jsx
import React from "react";

/**
 * Very small modal used across admin pages.
 * children: content
 * title: optional
 * onClose: function
 */
export default function Modal({ title, children, onClose, width = 720 }) {
  return (
    <div className="modal-backdrop" onMouseDown={onClose} style={backdropStyle}>
      <div className="modal-card" onMouseDown={(e) => e.stopPropagation()} style={{ ...cardStyle, width }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <div style={{ fontWeight: 700 }}>{title}</div>
          <button className="btn btn-ghost" onClick={onClose} aria-label="Close">✕</button>
        </div>
        <div>{children}</div>
      </div>
    </div>
  );
}

const backdropStyle = {
  position: "fixed",
  inset: 0,
  background: "rgba(6, 6, 8, 0.48)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: 60,
};

const cardStyle = {
  background: "#fff",
  borderRadius: 12,
  padding: 18,
  boxShadow: "0 10px 30px rgba(2,6,23,0.12)",
  maxHeight: "85vh",
  overflowY: "auto",
};

import React, { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";

/**
 * Enhanced ProtectedRoute component with proper navigation handling
 */
export default function ProtectedRoute({ children, redirect, requiresAdmin = false }) {
  const { user } = useContext(AuthContext);
  const [shouldRedirect, setShouldRedirect] = useState(false);

  useEffect(() => {
    // Check conditions and set redirect flag in useEffect (after render)
    if (!user) {
      setShouldRedirect(true);
    } else if (requiresAdmin && user.role !== "ADMIN") {
      setShouldRedirect(true);
    } else {
      setShouldRedirect(false);
    }
  }, [user, requiresAdmin]);

  useEffect(() => {
    // Perform redirect in a separate useEffect
    if (shouldRedirect && typeof redirect === "function") {
      redirect();
    }
  }, [shouldRedirect, redirect]);

  // Check if user is authenticated
  if (!user) {
    return (
      <div style={{ 
        display: "flex", 
        justifyContent: "center", 
        alignItems: "center", 
        height: "50vh",
        flexDirection: "column",
        gap: 16
      }}>
        <div style={{ fontSize: 48 }}>🔒</div>
        <h3>Authentication Required</h3>
        <p className="muted">Please sign in to access this page.</p>
        <button 
          className="btn btn-primary" 
          onClick={() => {
            if (typeof redirect === "function") redirect();
          }}
        >
          Sign In
        </button>
      </div>
    );
  }
  
  // Check if admin privileges are required
  if (requiresAdmin && user.role !== "ADMIN") {
    return (
      <div style={{ 
        display: "flex", 
        justifyContent: "center", 
        alignItems: "center", 
        height: "50vh",
        flexDirection: "column",
        gap: 16
      }}>
        <div style={{ fontSize: 48 }}>🚫</div>
        <h3>Admin Access Required</h3>
        <p className="muted">You don't have permission to access this page.</p>
        <button 
          className="btn btn-primary" 
          onClick={() => {
            if (typeof redirect === "function") redirect();
          }}
        >
          Go Back
        </button>
      </div>
    );
  }

  return <>{children}</>;
}
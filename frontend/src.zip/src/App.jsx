import React, { useContext, useState, useEffect } from "react";
import { AuthContext, AuthProvider } from "./context/AuthContext";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Toast from "./components/Toast";

// Import all pages
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import ProfilePage from "./pages/ProfilePage";
import UpdatePasswordPage from "./pages/UpdatePasswordPage";
import ProductListPage from "./pages/ProductListPage";
import ProductDetailPage from "./pages/ProductDetailPage";
import CartPage from "./pages/CartPage";
import OrdersPage from "./pages/OrdersPage";
import UserOrdersPage from "./pages/UserOrderPage";
import AdminLoginPage from "./pages/AdminLoginPage";
import AdminDashboardPage from "./pages/AdminDashboardPage";
import AdminProductsPage from "./pages/AdminProductsPage";
import AdminOrdersPage from "./pages/AdminOrdersPage";
import AdminUsersPage from "./pages/AdminUsersPage";
import ProtectedRoute from "./components/ProtectedRoute";

function AppContent() {
  const { user, setUser } = useContext(AuthContext);
  const [currentPage, setCurrentPage] = useState("home");
  const [pageParams, setPageParams] = useState({});
  const [toast, setToast] = useState(null);

  // Navigation function
  const navigateTo = (page, params = {}) => {
    setCurrentPage(page);
    setPageParams(params);
    window.scrollTo(0, 0);
  };

  // Handle login
  const handleLogin = () => {
    setToast({ type: "success", title: "Welcome!", text: "Successfully signed in" });
    navigateTo("home");
  };

  // Handle register
  const handleRegister = () => {
    setToast({ type: "success", title: "Welcome!", text: "Account created successfully" });
    navigateTo("home");
  };

  // Handle admin login
  const handleAdminLogin = () => {
    setToast({ type: "success", title: "Admin Access", text: "Welcome to admin dashboard" });
    navigateTo("adminDashboard");
  };

  // Render current page based on state
  const renderPage = () => {
    switch (currentPage) {
      case "home":
        return <HomePage onNavigate={navigateTo} />;
      
      case "login":
        return <LoginPage onLogin={handleLogin} onNavigate={navigateTo} />;
      
      case "register":
        return <RegisterPage onRegister={handleRegister} onNavigate={navigateTo} />;
      
      case "profile":
        return (
          <ProtectedRoute redirect={() => navigateTo("login")}>
            <ProfilePage onNavigate={navigateTo} />
          </ProtectedRoute>
        );
      
      case "updatePassword":
        return (
          <ProtectedRoute redirect={() => navigateTo("login")}>
            <UpdatePasswordPage onNavigate={navigateTo} />
          </ProtectedRoute>
        );
      
      case "products":
        return <ProductListPage onNavigate={navigateTo} q={pageParams.q} />;
      
      case "product":
        return <ProductDetailPage productId={pageParams.id} onNavigate={navigateTo} />;
      
      case "cart":
        return (
          <ProtectedRoute redirect={() => navigateTo("login")}>
            <CartPage onNavigate={navigateTo} />
          </ProtectedRoute>
        );
      
      case "orders":
        return (
          <ProtectedRoute redirect={() => navigateTo("login")}>
            <UserOrdersPage onNavigate={navigateTo} />
          </ProtectedRoute>
        );
      
      case "adminLogin":
        return <AdminLoginPage onLogin={handleAdminLogin} onNavigate={navigateTo} />;
      
      case "adminDashboard":
        return (
          <ProtectedRoute redirect={() => navigateTo("adminLogin")} requiresAdmin>
            <AdminDashboardPage onNavigate={navigateTo} />
          </ProtectedRoute>
        );
      
      case "adminProducts":
        return (
          <ProtectedRoute redirect={() => navigateTo("adminLogin")} requiresAdmin>
            <AdminProductsPage onNavigate={navigateTo} />
          </ProtectedRoute>
        );
      
      case "adminOrders":
        return (
          <ProtectedRoute redirect={() => navigateTo("adminLogin")} requiresAdmin>
            <AdminOrdersPage onNavigate={navigateTo} />
          </ProtectedRoute>
        );
      
      case "adminUsers":
        return (
          <ProtectedRoute redirect={() => navigateTo("adminLogin")} requiresAdmin>
            <AdminUsersPage onNavigate={navigateTo} />
          </ProtectedRoute>
        );
      
      default:
        return <HomePage onNavigate={navigateTo} />;
    }
  };

  return (
    <div className="app" style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <Toast msg={toast} onClose={() => setToast(null)} />
      
      {/* Navbar */}
      <Navbar onNavigate={navigateTo} />
      
      {/* Main Content */}
      <main style={{ flex: 1 }}>
        {renderPage()}
      </main>
      
      {/* Footer */}
      <Footer onNavigate={navigateTo} />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
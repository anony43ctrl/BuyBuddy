import React, { useContext, useEffect, useState } from "react";
import { orderService } from "../services/orderService";
import { AuthContext } from "../context/AuthContext";
import Toast from "../components/Toast";

const ORDER_STATUSES = ["PENDING", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED"];

export default function AdminOrdersPage() {
  const { token } = useContext(AuthContext);
  const [orders, setOrders] = useState([]);
  const [toast, setToast] = useState(null);
  const [busyId, setBusyId] = useState(null);

  useEffect(() => {
    let mounted = true;
    async function load() {
      try {
        const res = await orderService.getOrders(null, token);
        if (!mounted) return;
        setOrders(res || []);
      } catch (err) {
        console.error("getOrders", err);
        setToast({ type: "error", title: "Orders", text: "Failed to load orders" });
      }
    }
    load();
    return () => (mounted = false);
  }, [token]);

  async function updateStatus(orderId, orderStatus) {
    setBusyId(orderId);
    try {
      await orderService.adminUpdateOrderStatus(orderId, orderStatus, token);
      setToast({ type: "success", title: "Order updated", text: `Order #${orderId} → ${orderStatus}` });
      const res = await orderService.getOrders(null, token);
      setOrders(res || []);
    } catch (err) {
      console.error("updateStatus", err);
      setToast({ type: "error", title: "Error", text: err.message || "Failed to update order" });
    } finally {
      setBusyId(null);
    }
  }

  function calculateTotal(order) {
    if (typeof order.total_amount === "number") return order.total_amount;
    return (order.items || []).reduce((sum, it) => sum + (Number(it.price || 0) * Number(it.quantity || 0)), 0);
  }

  function getCustomerLabel(order) {
    if (order.user?.email) return order.user.email;
    if (order.user_id) return `User #${order.user_id}`;
    return <span className="muted">Unknown</span>;
  }

  return (
    <div className="container" style={{ paddingTop: 20 }}>
      <Toast msg={toast} onClose={() => setToast(null)} />
      <h2 style={{ marginTop: 0 }}>Manage Orders</h2>

      <table className="table" style={{ marginTop: 12 }}>
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Items</th>
            <th>Total</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((o) => (
            <tr key={o.id}>
              <td>{o.id}</td>
              <td>{getCustomerLabel(o)}</td>
              <td>
                {(o.items || []).map((it) => (
                  <div key={it.id} style={{ fontSize: 13, marginBottom: 4 }}>
                    {it.product?.name || it.product_id} × {it.quantity} (₹{Number(it.price).toFixed(2)})
                  </div>
                ))}
              </td>
              <td>₹{calculateTotal(o).toFixed(2)}</td>
              <td>
                <select value={o.orderStatus} onChange={(e) => updateStatus(o.id, e.target.value)} disabled={busyId === o.id}>
                  {ORDER_STATUSES.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </td>
            </tr>
          ))}
          {orders.length === 0 && (
            <tr><td colSpan={5} className="muted">No orders found</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
import React, { useContext, useState, useRef, useEffect } from "react";
import { authService } from "../services/authService"; // Direct import
import { AuthContext } from "../context/AuthContext";
import { sendWelcomeNotification } from "../utils/notify";

export default function RegisterPage({ onRegister, onNavigate }) {
  const { setUser } = useContext(AuthContext);
  const [fullname, setFullname] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [address, setAddress] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const nameRef = useRef(null);

  useEffect(() => nameRef.current && nameRef.current.focus(), []);

  async function submit(e) {
    e && e.preventDefault();
    setError(null);
    if (!fullname || !email || password.length < 6) {
      setError("Please complete the form. Password must be at least 6 characters.");
      return;
    }
    setBusy(true);
    try {
      console.log("Attempting registration:", { fullname, email }); // Debug log
      const user = await authService.register({ fullname, email, password, phoneNumber, address });
      console.log("Registration successful:", user); // Debug log
      setUser(user);
      if (typeof onRegister === "function") onRegister();
      sendWelcomeNotification(email, phoneNumber, fullname);
    } catch (err) {
      console.error("Registration error:", err); // Debug log
      setError(err?.message || "Registration failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-page container" style={{ display: "flex", justifyContent: "center", paddingTop: 56 }}>
      <div className="auth-card" style={{ width: 640, padding: 28, borderRadius: 12 }}>
        <div style={{ display: "flex", gap: 18, alignItems: "center", marginBottom: 6 }}>
          <div style={{ width: 64, height: 64, borderRadius: 12, background: "linear-gradient(135deg,#06b6d4,#0ea5e9)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 22 }}>
            +
          </div>
          <div>
            <h2 style={{ margin: 0 }}>Create your account</h2>
            <p className="muted" style={{ margin: 0, fontSize: 13 }}>Join us and start ordering instantly.</p>
          </div>
        </div>

        {error && <div className="msg error" style={{ marginTop: 12 }}>{error}</div>}

        <form onSubmit={submit} style={{ marginTop: 14, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <div style={{ gridColumn: "1 / -1" }}>
            <label style={{ fontWeight: 600 }}>Full name</label>
            <input ref={nameRef} value={fullname} onChange={(e) => setFullname(e.target.value)} required />
          </div>

          <div>
            <label style={{ fontWeight: 600 }}>Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>

          <div>
            <label style={{ fontWeight: 600 }}>Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} />
            <div style={{ fontSize: 12, color: password.length >= 6 ? "#16a34a" : "#666", marginTop: 6 }}>
              {password.length >= 6 ? "Password length OK" : "Minimum 6 characters"}
            </div>
          </div>

          <div>
            <label style={{ fontWeight: 600 }}>Phone (optional)</label>
            <input value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} />
          </div>

          <div style={{ gridColumn: "1 / -1" }}>
            <label style={{ fontWeight: 600 }}>Address (optional)</label>
            <input value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>

          <div style={{ gridColumn: "1 / -1", display: "flex", gap: 8, marginTop: 6 }}>
            <button className="btn btn-primary" style={{ flex: 1 }} disabled={busy}>
              {busy ? "Creating account…" : "Create account"}
            </button>
            <button type="button" className="btn btn-outline" onClick={() => onNavigate("login")}>
              Already have an account
            </button>
          </div>
        </form>

        <div style={{ marginTop: 16, fontSize: 13, color: "#666", textAlign: "center" }}>
          By creating an account you agree to our <strong>Terms</strong> and <strong>Privacy Policy</strong>.
        </div>
      </div>
    </div>
  );
}
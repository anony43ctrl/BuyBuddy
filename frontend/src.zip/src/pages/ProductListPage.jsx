import React, { useEffect, useMemo, useState, useRef } from "react";
import { productService } from "../services/productService";
import ProductCard from "../components/ProductCard";
import Toast from "../components/Toast";

function useDebounce(value, ms = 350) {
  const [deb, setDeb] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDeb(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return deb;
}

export default function ProductListPage({ onNavigate, q: initialQ }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [query, setQuery] = useState(initialQ || "");
  const debQuery = useDebounce(query, 400);
  const [sort, setSort] = useState("newest");
  const [page, setPage] = useState(1);
  const pageSize = 12;
  const [toast, setToast] = useState(null);
  const allProductsRef = useRef([]);

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    handleSearch(debQuery);
  }, [debQuery]);

  async function loadProducts() {
    setLoading(true);
    setError(null);
    try {
      const res = await productService.getProducts();
      allProductsRef.current = res || [];
      setProducts(res || []);
      setPage(1);
    } catch (e) {
      setError(e.message || "Failed to load products");
    } finally {
      setLoading(false);
    }
  }

  async function handleSearch(q) {
    if (!q) {
      setProducts(allProductsRef.current);
      setPage(1);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await productService.searchProducts(q);
      setProducts(res || []);
      setPage(1);
    } catch (e) {
      setError(e.message || "Search failed");
    } finally {
      setLoading(false);
    }
  }

  function handleSort(next) {
    setSort(next);
  }

  const sorted = useMemo(() => {
    const arr = [...products];
    if (sort === "price_asc") arr.sort((a, b) => a.price - b.price);
    else if (sort === "price_desc") arr.sort((a, b) => b.price - a.price);
    else arr.sort((a, b) => (b.id || 0) - (a.id || 0));
    return arr;
  }, [products, sort]);

  const pageCount = Math.max(1, Math.ceil(sorted.length / pageSize));
  const visible = sorted.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div className="container" style={{ marginTop: 12 }}>
      <Toast msg={toast} onClose={() => setToast(null)} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
        <h1>Products</h1>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <input placeholder="Search products..." value={query} onChange={(e) => setQuery(e.target.value)} style={{ width: 280 }} />
          <select value={sort} onChange={(e) => handleSort(e.target.value)} style={{ padding: "8px 10px", borderRadius: 8 }}>
            <option value="newest">Newest</option>
            <option value="price_asc">Price: low → high</option>
            <option value="price_desc">Price: high → low</option>
          </select>
        </div>
      </div>

      {loading && <p>Loading…</p>}
      {error && <p className="msg error">{error}</p>}

      <div className="product-grid" style={{ marginTop: 12 }}>
        {visible.map(p => (
          <ProductCard key={p.id} product={p} onView={(id) => onNavigate("product", { id })} onAddToCart={(id) => onNavigate("product", { id })} />
        ))}
      </div>

      <div style={{ display: "flex", justifyContent: "center", gap: 8, marginTop: 20, alignItems: "center" }}>
        <button className="btn" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}>Prev</button>
        <div style={{ padding: "6px 10px", background: "#fff", borderRadius: 8 }}>{page} / {pageCount}</div>
        <button className="btn" onClick={() => setPage((p) => Math.min(pageCount, p + 1))} disabled={page === pageCount}>Next</button>
      </div>
    </div>
  );
}
import React, { useContext, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { productService } from "../services/productService";
import { cartService } from "../services/cartService";
import { AuthContext } from "../context/AuthContext";
import ProductCard from "../components/ProductCard";
import Toast from "../components/Toast";

export default function ProductDetailPage({ onNavigate }) {
  const { user, token } = useContext(AuthContext);
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [qty, setQty] = useState(1);
  const [related, setRelated] = useState([]);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    (async () => {
      try {
        console.log("Fetching product with ID:", id); // Debug log
        const p = await productService.getProduct(id);
        console.log("Product data:", p); // Debug log
        if (!mounted) return;
        setProduct(p);
        if (p && p.category) {
          try {
            const rel = await productService.getProductsByCategory(p.category);
            if (!mounted) return;
            setRelated((rel || []).filter((r) => r.id !== p.id).slice(0, 6));
          } catch (e) {
            console.error("Error loading related products:", e);
          }
        }
      } catch (e) {
        console.error("Error loading product:", e);
        setToast({ type: "error", title: "Load error", text: e.message || "Could not load product." });
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => (mounted = false);
  }, [id]);

  async function handleAddToCart() {
    if (!user) {
      onNavigate("login");
      return;
    }
    setLoading(true);
    try {
      setToast({ type: "info", title: "Adding", text: "Adding to cart..." });
      await cartService.addToCart(user.id, product.id, qty, token);
      setToast({ type: "success", title: "Added", text: `${product.name} (x${qty}) added to cart.` });
    } catch (e) {
      setToast({ type: "error", title: "Failed", text: e.message || "Could not add to cart." });
    } finally {
      setLoading(false);
    }
  }

  if (!product && !loading) return <div className="container"><p className="msg error">Product not found</p></div>;
  if (loading && !product) return <div className="container"><p>Loading product…</p></div>;

  return (
    <div className="container" style={{ marginTop: 12 }}>
      <Toast msg={toast} onClose={() => setToast(null)} />
      <div style={{ display: "grid", gridTemplateColumns: "1fr 420px", gap: 24 }}>
        <div>
          <img
            src={product.imageUrl || product.imageURL || `https://via.placeholder.com/1200x700?text=${encodeURIComponent(product.name)}`}
            alt={product.name}
            style={{ width: "100%", borderRadius: 10 }}
          />
          <div style={{ marginTop: 12 }}>
            <h1 style={{ marginBottom: 6 }}>{product.name}</h1>
            <div className="muted">{product.description}</div>
          </div>
        </div>

        <aside style={{ background: "#fff", padding: 20, borderRadius: 10, boxShadow: "0 6px 20px rgba(16,24,40,0.06)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ fontSize: 24, fontWeight: 800 }}>₹{product.price?.toFixed(2) || "0.00"}</div>
            <div className="muted">
              {typeof product.stockQuantity === "number"
                ? `${product.stockQuantity} in stock`
                : "Stock info unavailable"}
            </div>
          </div>

          <div style={{ marginTop: 14 }}>
            <label style={{ display: "inline-block", marginBottom: 8 }}>Quantity</label>
            <input
              type="number"
              min="1"
              max={product.stockQuantity}
              value={qty}
              onChange={(e) => setQty(Math.max(1, Number(e.target.value) || 1))}
              style={{ width: 100 }}
            />
          </div>

          <div style={{ marginTop: 16, display: "flex", gap: 8 }}>
            <button
              className="btn btn-primary"
              onClick={handleAddToCart}
              disabled={product.stockQuantity <= 0 || loading}
            >
              {product.stockQuantity > 0 ? "Add to cart" : "Out of stock"}
            </button>
            <button className="btn btn-outline" onClick={() => onNavigate("products")}>Back</button>
          </div>

          <div style={{ marginTop: 18 }}>
            <h4 style={{ marginBottom: 8 }}>Details</h4>
            <ul style={{ color: "#555" }}>
              <li>SKU: {product.sku || "—"}</li>
              <li>Category: {product.category}</li>
              <li>Availability: {product.stockQuantity > 0 ? "In stock" : "Out of stock"}</li>
            </ul>
          </div>
        </aside>
      </div>

      {related && related.length > 0 && (
        <div style={{ marginTop: 28 }}>
          <h3>Related items</h3>
          <div className="product-grid" style={{ marginTop: 12 }}>
            {related.map((r) => (
              <ProductCard
                key={r.id}
                product={r}
                onView={(id) => onNavigate("product", { id })}
                onAddToCart={(id) => onNavigate("product", { id })}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
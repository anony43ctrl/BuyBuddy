import React, { useContext, useEffect, useState } from "react";
import { productService } from "../services/productService";
import { AuthContext } from "../context/AuthContext";
import AdminProductForm from "../components/AdminProductForm";
import Toast from "../components/Toast";

export default function AdminProductsPage({ onNavigate }) {
  const { user } = useContext(AuthContext);
  const [products, setProducts] = useState([]);
  const [editing, setEditing] = useState(null);
  const [creating, setCreating] = useState(false);
  const [toast, setToast] = useState(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      const prods = await productService.adminGetAllProducts();
      console.log("Admin products:", prods); // Debug
      const normalized = prods.map(p => ({
        ...p,
        imageURL: p.imageURL || "",
        stockQuantity: p.stockQuantity || 0,
        active: p.active ?? true,
      }));
      setProducts(normalized);
    } catch (err) {
      console.error("load products", err);
      setToast({ type: "error", title: "Products", text: "Failed to load products" });
    }
  }

  useEffect(() => {
    load();
  }, []);

  function requireAdminAction() {
    if (!user || user.role !== "ADMIN") {
      setToast({
        type: "error",
        title: "Admin required",
        text: "You must sign in as an admin to perform this action.",
      });
      return false;
    }
    return true;
  }

  async function handleCreate(payload) {
    if (!requireAdminAction()) return;
    setBusy(true);
    try {
      await productService.createProduct(payload);
      setToast({ type: "success", title: "Created", text: "Product created" });
      setCreating(false);
      await load();
    } catch (err) {
      console.error("create product", err);
      setToast({ type: "error", title: "Error", text: err.message || "Failed to create" });
    } finally {
      setBusy(false);
    }
  }

  async function handleUpdate(id, payload) {
    if (!requireAdminAction()) return;
    setBusy(true);
    try {
      await productService.updateProduct(id, payload);
      setToast({ type: "success", title: "Updated", text: "Product updated" });
      setEditing(null);
      await load();
    } catch (err) {
      console.error("update product", err);
      setToast({ type: "error", title: "Error", text: err.message || "Failed to update" });
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete(id) {
    if (!requireAdminAction()) return;
    if (!confirm("Delete product? This action cannot be undone.")) return;
    setBusy(true);
    try {
      await productService.deleteProduct(id);
      setToast({ type: "success", title: "Deleted", text: "Product removed" });
      await load();
    } catch (err) {
      console.error("delete product", err);
      setToast({ type: "error", title: "Error", text: err.message || "Failed to delete" });
    } finally {
      setBusy(false);
    }
  }

  async function handleReactivate(id) {
    if (!requireAdminAction()) return;
    setBusy(true);
    try {
      await productService.reactivateProduct(id);
      setToast({ type: "success", title: "Reactivated", text: "Product reactivated" });
      await load();
    } catch (err) {
      console.error("reactivate product", err);
      setToast({ type: "error", title: "Error", text: err.message || "Failed to reactivate" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container" style={{ paddingTop: 20 }}>
      <Toast msg={toast} onClose={() => setToast(null)} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2 style={{ margin: 0 }}>Products</h2>
        <div>
          <button className="btn" onClick={() => {
            if (!requireAdminAction()) return;
            setCreating(true);
          }}>Add product</button>
        </div>
      </div>

      {creating && (
        <div style={{ marginTop: 16 }}>
          <h4>Create product</h4>
          <AdminProductForm
            onCancel={() => setCreating(false)}
            onSave={(p) => handleCreate(p)}
            busy={busy}
          />
        </div>
      )}

      {editing && (
        <div style={{ marginTop: 16 }}>
          <h4>Edit product</h4>
          <AdminProductForm
            initial={editing}
            onCancel={() => setEditing(null)}
            onSave={(p) => handleUpdate(editing.id, p)}
            busy={busy}
          />
        </div>
      )}

      <div style={{ marginTop: 18 }}>
        <table className="table">
          <thead>
            <tr>
              <th style={{ width: 60 }}>ID</th>
              <th>Image</th>
              <th>Name</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Category</th>
              <th>Status</th>
              <th style={{ width: 200 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} style={!p.active ? { opacity: 0.5 } : {}}>
                <td>{p.id}</td>
                <td>
                  {p.imageURL ? (
                    <img 
                      src={p.imageURL} 
                      alt={p.name} 
                      style={{ width: 60, height: 40, objectFit: "cover", borderRadius: 4 }} 
                    />
                  ) : (
                    <span className="muted">No image</span>
                  )}
                </td>
                <td>{p.name}</td>
                <td>₹{Number(p.price).toFixed(2)}</td>
                <td>{p.stockQuantity}</td>
                <td>{p.category}</td>
                <td>{p.active ? "Active" : "Inactive"}</td>
                <td>
                  {p.active ? (
                    <>
                      <button 
                        className="btn btn-outline" 
                        onClick={() => {
                          if (!requireAdminAction()) return;
                          setEditing(p);
                        }}
                        style={{ marginRight: 8 }}
                      >
                        Edit
                      </button>
                      <button 
                        className="btn btn-danger" 
                        onClick={() => handleDelete(p.id)}
                      >
                        Delete
                      </button>
                    </>
                  ) : (
                    <button 
                      className="btn btn-success" 
                      onClick={() => handleReactivate(p.id)}
                    >
                      Reactivate
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {products.length === 0 && (
              <tr><td colSpan={8} className="muted">No products yet</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
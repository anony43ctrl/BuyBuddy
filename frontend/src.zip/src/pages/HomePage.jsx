import React, { useEffect, useState, useRef, useContext } from "react";
import { productService } from "../services/productService";
import { cartService } from "../services/cartService";
import ProductCard from "../components/ProductCard";
import Toast from "../components/Toast";
import { AuthContext } from "../context/AuthContext";

export default function HomePage({ onNavigate }) {
  const { user, token } = useContext(AuthContext);
  const [products, setProducts] = useState([]);
  const [featured, setFeatured] = useState([]);
  const [categories, setCategories] = useState([]);
  const [activeCategory, setActiveCategory] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [toast, setToast] = useState(null);
  const [wishlist, setWishlist] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("wishlist_v1") || "[]");
    } catch {
      return [];
    }
  });

  const carouselRef = useRef();
  const carouselTimer = useRef();
  const heroRef = useRef();

  useEffect(() => {
    const handleScroll = () => {
      if (heroRef.current) {
        const scrolled = window.pageYOffset;
        const parallax = scrolled * 0.3;
        heroRef.current.style.transform = `translateY(${parallax}px)`;
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    (async () => {
      try {
        const all = await productService.getProducts();
        if (!mounted) return;
        const list = all || [];
        setProducts(list);
        const feat = [...list].sort((a, b) => (b.id || 0) - (a.id || 0)).slice(0, 8);
        setFeatured(feat);
        const cats = Array.from(new Set(list.map((p) => p.category))).filter(Boolean);
        setCategories(cats);
        setError(null);
      } catch (err) {
        setError(err?.message || "Unable to load products.");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
      clearInterval(carouselTimer.current);
    };
  }, []);

  useEffect(() => {
    if (!carouselRef.current) return;
    carouselTimer.current = setInterval(() => {
      const el = carouselRef.current;
      if (!el) return;
      const max = el.children.length;
      if (!max) return;
      const cur = el.dataset.index ? Number(el.dataset.index) : 0;
      const next = (cur + 1) % max;
      el.dataset.index = next;
      el.style.transform = `translateX(-${next * 100}%)`;
    }, 5000);
    return () => clearInterval(carouselTimer.current);
  }, [featured]);

  function saveWishlist(next) {
    setWishlist(next);
    try {
      localStorage.setItem("wishlist_v1", JSON.stringify(next));
    } catch (e) {
      // ignore
    }
  }

  function toggleWishlist(productId) {
    const exists = wishlist.includes(productId);
    if (exists) {
      saveWishlist(wishlist.filter((id) => id !== productId));
      setToast({ type: "info", title: "💙 Removed", text: "Removed from wishlist" });
    } else {
      saveWishlist([productId, ...wishlist]);
      setToast({ type: "success", title: "💖 Saved", text: "Added to your wishlist" });
    }
  }

  async function chooseCategory(cat) {
    if (cat === activeCategory) {
      setActiveCategory(null);
      try {
        setLoading(true);
        const all = await productService.getProducts();
        setProducts(all || []);
      } catch (e) {
        setError(e.message || "Failed to load products.");
      } finally {
        setLoading(false);
      }
      return;
    }
    setActiveCategory(cat);
    setLoading(true);
    try {
      const byCat = await productService.getProductsByCategory(cat);
      setProducts(byCat || []);
    } catch (e) {
      setError(e.message || "Failed to load category.");
    } finally {
      setLoading(false);
    }
  }

  async function quickAdd(product) {
    if (!user) {
      setToast({ type: "info", title: "🔐 Sign in required", text: "Please sign in to add to cart" });
      onNavigate("login");
      return;
    }
    try {
      setToast({ type: "info", title: "✨ Adding…", text: `Adding ${product.name} to your cart` });
      await cartService.addToCart(user.id, product.id, 1, token);
      setToast({ type: "success", title: "🎉 Added", text: `${product.name} added to cart` });
    } catch (err) {
      setToast({ type: "error", title: "❌ Failed", text: err?.message || "Could not add to cart" });
    }
  }

  function viewProduct(id) {
    onNavigate("product", { id });
  }

  // Enhanced empty state with better visuals
  function EmptyState({ title, subtitle, cta }) {
    return (
      <div style={{ 
        textAlign: "center", 
        padding: "80px 40px",
        background: "linear-gradient(135deg, rgba(var(--brand-rgb), 0.02), rgba(var(--brand-2-rgb), 0.02))",
        borderRadius: 24,
        border: "1px solid var(--border)"
      }}>
        <div style={{ 
          fontSize: 64, 
          fontWeight: 800, 
          background: "linear-gradient(135deg, var(--muted), var(--border))",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          marginBottom: 16
        }}>
          ∅
        </div>
        <h3 style={{ marginTop: 8, color: "var(--text)" }}>{title}</h3>
        <div className="muted" style={{ marginTop: 8, fontSize: 16 }}>{subtitle}</div>
        {cta && (
          <div style={{ marginTop: 24 }}>
            <button 
              className="btn btn-primary" 
              onClick={cta.onClick}
              style={{
                background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                transform: "translateY(0)",
                transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                boxShadow: "0 8px 32px rgba(var(--brand-rgb), 0.3)"
              }}
              onMouseEnter={(e) => {
                e.target.style.transform = "translateY(-2px)";
                e.target.style.boxShadow = "0 12px 40px rgba(var(--brand-rgb), 0.4)";
              }}
              onMouseLeave={(e) => {
                e.target.style.transform = "translateY(0)";
                e.target.style.boxShadow = "0 8px 32px rgba(var(--brand-rgb), 0.3)";
              }}
            >
              {cta.label}
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div style={{ 
      animation: "fadeIn 0.6s cubic-bezier(0.4, 0, 0.2, 1) both",
      position: "relative",
      overflow: "hidden"
    }}>
      <Toast msg={toast} onClose={() => setToast(null)} />

      {/* Background decorative elements */}
      <div style={{
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        height: "100vh",
        background: "radial-gradient(ellipse at top, rgba(var(--brand-rgb), 0.1) 0%, transparent 50%)",
        pointerEvents: "none",
        zIndex: -2
      }} />

      {/* Floating geometric shapes */}
      <div style={{
        position: "absolute",
        top: "20%",
        right: "10%",
        width: 200,
        height: 200,
        background: "linear-gradient(135deg, rgba(var(--brand-rgb), 0.05), rgba(var(--brand-2-rgb), 0.05))",
        borderRadius: "50%",
        filter: "blur(40px)",
        animation: "float 6s ease-in-out infinite",
        zIndex: -1
      }} />

      <div style={{
        position: "absolute",
        top: "60%",
        left: "5%",
        width: 150,
        height: 150,
        background: "linear-gradient(135deg, rgba(var(--brand-2-rgb), 0.08), rgba(var(--brand-rgb), 0.03))",
        borderRadius: "30%",
        filter: "blur(30px)",
        animation: "float 8s ease-in-out infinite reverse",
        zIndex: -1
      }} />

      {/* ENHANCED HERO SECTION */}
      <section 
        ref={heroRef}
        className="hero" 
        style={{ 
          padding: "120px 0 80px",
          position: "relative",
          background: "linear-gradient(135deg, var(--bg) 0%, var(--surface) 100%)",
          overflow: "hidden"
        }}
      >
        {/* Hero gradient overlay */}
        <div style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: "linear-gradient(135deg, rgba(var(--brand-rgb), 0.03) 0%, rgba(var(--brand-2-rgb), 0.05) 100%)",
          zIndex: -1
        }} />

        <div className="container" style={{ 
          display: "grid", 
          gridTemplateColumns: "1.2fr 500px", 
          gap: 48, 
          alignItems: "center",
          position: "relative",
          zIndex: 1
        }}>
          <div style={{ animation: "slideInLeft 0.8s cubic-bezier(0.4, 0, 0.2, 1) both" }}>
            <div style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 8,
              background: "linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))",
              backdropFilter: "blur(20px)",
              padding: "8px 16px",
              borderRadius: 50,
              color: "var(--text)",
              fontWeight: 700,
              letterSpacing: "0.02em",
              marginBottom: 24,
              border: "1px solid rgba(255,255,255,0.1)",
              boxShadow: "0 8px 32px rgba(0,0,0,0.1)"
            }}>
              <div style={{
                width: 8,
                height: 8,
                borderRadius: "50%",
                background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                animation: "pulse 2s ease-in-out infinite"
              }} />
              Curated picks · Limited time
            </div>

            <h1 style={{ 
              color: "var(--text)", 
              fontSize: 56, 
              lineHeight: 1.1, 
              margin: "0 0 24px", 
              fontWeight: 900,
              background: "linear-gradient(135deg, var(--text) 0%, var(--muted) 100%)",
              WebkitBackgroundClip: "text",
              letterSpacing: "-0.02em"
            }}>
              Beautiful products,{" "}
              <span style={{
                background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent"
              }}>
                thoughtfully selected
              </span>
            </h1>

            <p className="muted" style={{ 
              color: "var(--muted)", 
              fontSize: 18, 
              maxWidth: 580, 
              lineHeight: 1.6,
              marginBottom: 32
            }}>
              Explore a hand-picked collection of electronics, lifestyle goods and everyday essentials — all demo-connected to your FastAPI backend with seamless integration.
            </p>

            <div style={{ 
              display: "flex", 
              gap: 16, 
              flexWrap: "wrap",
              marginBottom: 40
            }}>
              <button 
                className="btn btn-primary" 
                onClick={() => onNavigate("products")}
                style={{
                  background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                  padding: "16px 32px",
                  fontSize: 16,
                  fontWeight: 700,
                  boxShadow: "0 8px 32px rgba(var(--brand-rgb), 0.3)",
                  transform: "translateY(0)",
                  transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                }}
                onMouseEnter={(e) => {
                  e.target.style.transform = "translateY(-3px)";
                  e.target.style.boxShadow = "0 16px 48px rgba(var(--brand-rgb), 0.4)";
                }}
                onMouseLeave={(e) => {
                  e.target.style.transform = "translateY(0)";
                  e.target.style.boxShadow = "0 8px 32px rgba(var(--brand-rgb), 0.3)";
                }}
              >
                Shop the collection
              </button>
              
              <button 
                className="btn btn-outline" 
                onClick={() => onNavigate("register")}
                style={{
                  padding: "16px 32px",
                  fontSize: 16,
                  fontWeight: 600,
                  borderWidth: 2,
                  transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                }}
              >
                Create account
              </button>
              
              <button
                className="btn"
                onClick={() => {
                  const el = document.querySelector(".product-grid");
                  if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
                }}
                style={{
                  padding: "16px 24px",
                  fontSize: 16,
                  fontWeight: 600,
                  color: "var(--muted)",
                  transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                }}
              >
                See featured ↓
              </button>
            </div>

            {/* Enhanced trust indicators */}
            <div style={{ 
              display: "flex", 
              gap: 24, 
              alignItems: "center",
              flexWrap: "wrap"
            }}>
              <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <div style={{
                  width: 24,
                  height: 24,
                  borderRadius: "50%",
                  background: "linear-gradient(135deg, #10b981, #059669)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center"
                }}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                    <path d="M7 12l3 3 7-7" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <div className="muted" style={{ fontSize: 15, fontWeight: 500 }}>
                  Fast demo — no payment required
                </div>
              </div>

              <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                <div className="badge" style={{
                  background: "linear-gradient(135deg, rgba(var(--brand-rgb), 0.1), rgba(var(--brand-2-rgb), 0.1))",
                  color: "var(--brand)",
                  border: "1px solid rgba(var(--brand-rgb), 0.2)",
                  fontWeight: 600
                }}>
                  Secure
                </div>
                <div className="badge" style={{
                  background: "linear-gradient(135deg, rgba(255,138,101,0.1), rgba(255,138,101,0.05))",
                  color: "#ff8a65",
                  border: "1px solid rgba(255,138,101,0.2)",
                  fontWeight: 600
                }}>
                  Curated
                </div>
              </div>
            </div>
          </div>

          {/* Enhanced featured carousel */}
          <div style={{ 
            position: "relative",
            animation: "slideInRight 0.8s cubic-bezier(0.4, 0, 0.2, 1) 0.2s both"
          }}>
            <div style={{
              borderRadius: 24,
              overflow: "hidden",
              boxShadow: "0 32px 128px rgba(0,0,0,0.2)",
              border: "1px solid rgba(255,255,255,0.1)",
              background: "linear-gradient(135deg, var(--surface), rgba(var(--surface), 0.8))",
              backdropFilter: "blur(20px)"
            }}>
              <div style={{ 
                display: "flex", 
                alignItems: "center", 
                justifyContent: "space-between", 
                padding: "20px 24px",
                background: "linear-gradient(135deg, rgba(255,255,255,0.08), rgba(255,255,255,0.03))",
                borderBottom: "1px solid rgba(255,255,255,0.05)"
              }}>
                <div style={{ fontWeight: 800, color: "var(--text)", fontSize: 18 }}>Featured</div>
                <div className="muted" style={{ 
                  color: "var(--muted)",
                  background: "rgba(var(--brand-rgb), 0.1)",
                  padding: "4px 12px",
                  borderRadius: 20,
                  fontSize: 14,
                  fontWeight: 600
                }}>
                  {featured.length} items
                </div>
              </div>

              <div style={{ overflow: "hidden", position: "relative" }}>
                <div
                  ref={carouselRef}
                  data-index="0"
                  style={{
                    display: "flex",
                    width: `${(featured.length || 1) * 100}%`,
                    transition: "transform 600ms cubic-bezier(0.25, 0.46, 0.45, 0.94)"
                  }}
                >
                  {featured.length ? featured.map((f, index) => (
                    <div key={f.id} style={{ 
                      width: `${100 / (featured.length || 1)}%`, 
                      padding: 20, 
                      boxSizing: "border-box" 
                    }}>
                      <div style={{ 
                        display: "flex", 
                        gap: 16, 
                        alignItems: "center",
                        background: "linear-gradient(135deg, rgba(255,255,255,0.02), transparent)",
                        borderRadius: 16,
                        padding: 16
                      }}>
                        <div style={{
                          position: "relative",
                          borderRadius: 16,
                          overflow: "hidden",
                          flexShrink: 0
                        }}>
                          {/* <img 
                            src={`https://via.placeholder.com/320x200?text=${encodeURIComponent(f.name)}`} 
                            alt={f.name} 
                            style={{ 
                              width: 160, 
                              height: 110, 
                              objectFit: "cover",
                              transition: "transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                            }} 
                          /> */}


                          <img
  src={f.imageUrl || `https://dummyimage.com/320x200/cccccc/000000&text=${encodeURIComponent(f.name)}`}
  alt={f.name}
  style={{
    width: 160,
    height: 110,
    objectFit: "cover",
    transition: "transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
  }}
  onError={(e) => {
    e.target.src = "/default-image.jpg"; // fallback image
  }}
/>

                          <div style={{
                            position: "absolute",
                            top: 0,
                            left: 0,
                            right: 0,
                            bottom: 0,
                            background: "linear-gradient(135deg, transparent, rgba(0,0,0,0.1))"
                          }} />
                        </div>
                        
                        <div style={{ color: "var(--text)", flex: 1 }}>
                          <div style={{ 
                            fontSize: 20, 
                            fontWeight: 800,
                            marginBottom: 8,
                            background: "linear-gradient(135deg, var(--text), var(--muted))",
                            WebkitBackgroundClip: "text"
                          }}>
                            {f.name}
                          </div>
                          <div className="muted" style={{ 
                            color: "var(--muted)", 
                            marginBottom: 16,
                            lineHeight: 1.4,
                            fontSize: 14
                          }}>
                            {f.description ? f.description.slice(0, 80) + (f.description.length > 80 ? "…" : "") : "Premium quality product"}
                          </div>
                          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                            <div style={{ 
                              fontWeight: 900, 
                              fontSize: 22,
                              background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                              WebkitBackgroundClip: "text",
                              WebkitTextFillColor: "transparent"
                            }}>
                              ₹{f.price.toFixed(2)}
                            </div>
                            <button 
                              className="btn btn-outline" 
                              onClick={() => viewProduct(f.id)}
                              style={{
                                padding: "8px 16px",
                                fontSize: 14,
                                fontWeight: 600
                              }}
                            >
                              View
                            </button>
                            <button 
                              className="btn" 
                              onClick={() => quickAdd(f)}
                              style={{
                                padding: "8px 16px",
                                fontSize: 14,
                                fontWeight: 600,
                                background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                                color: "#fff"
                              }}
                            >
                              Add
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )) : (
                    <div style={{ padding: 40, width: "100%", textAlign: "center" }}>
                      <div className="muted">No featured items yet</div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Enhanced carousel controls */}
            <div style={{ 
              display: "flex", 
              gap: 8, 
              justifyContent: "center", 
              marginTop: 20 
            }}>
              {(featured || []).map((_, i) => {
                const curIndex = Number(carouselRef.current?.dataset?.index || 0);
                return (
                  <button
                    key={i}
                    onClick={() => {
                      if (!carouselRef.current) return;
                      carouselRef.current.dataset.index = i;
                      carouselRef.current.style.transform = `translateX(-${i * 100}%)`;
                      clearInterval(carouselTimer.current);
                      carouselTimer.current = setInterval(() => {
                        const el = carouselRef.current;
                        if (!el) return;
                        const max = el.children.length;
                        const cur = Number(el.dataset.index || 0);
                        const next = (cur + 1) % max;
                        el.dataset.index = next;
                        el.style.transform = `translateX(-${next * 100}%)`;
                      }, 5000);
                    }}
                    className="chip"
                    aria-label={`Go to slide ${i + 1}`}
                    style={{
                      width: i === curIndex ? 32 : 16,
                      height: 16,
                      padding: 0,
                      borderRadius: 8,
                      background: i === curIndex 
                        ? "linear-gradient(135deg, var(--brand), var(--brand-2))" 
                        : "rgba(var(--muted-rgb), 0.3)",
                      border: "none",
                      transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                      cursor: "pointer"
                    }}
                  />
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* ENHANCED PROMO SECTION */}
      <section style={{ padding: "40px 0 20px" }}>
        <div className="container" style={{ 
          display: "grid", 
          gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", 
          gap: 24 
        }}>
          <PromoCard
            title="Free demo checkout"
            subtitle="No real payments — just try flows"
            icon={
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                <rect x="2" y="4" width="20" height="16" rx="3" stroke="currentColor" strokeWidth="1.5"/>
                <path d="M2 8h20" stroke="currentColor" strokeWidth="1.5"/>
                <path d="M6 12h8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                <path d="M6 15h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            }
            gradient="linear-gradient(135deg, #0ea5e9, #0284c7)"
          />
          <PromoCard
            title="Curated quality"
            subtitle="Hand-picked items for real value"
            icon={
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                <path d="M12 2l2.4 7.2h7.6l-6 4.8 2.4 7.2L12 17.4l-6.4 3.8 2.4-7.2-6-4.8h7.6L12 2z" stroke="currentColor" strokeWidth="1.2" fill="rgba(255,138,101,0.1)"/>
              </svg>
            }
            gradient="linear-gradient(135deg, #ff8a65, #f57c00)"
          />
          <PromoCard
            title="Secure & private"
            subtitle="We never store payment details in demo"
            icon={
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                <rect x="3" y="11" width="18" height="11" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                <circle cx="12" cy="16" r="1" fill="currentColor"/>
                <path d="M7 11V7a5 5 0 0110 0v4" stroke="currentColor" strokeWidth="1.5"/>
              </svg>
            }
            gradient="linear-gradient(135deg, #16a34a, #15803d)"
          />
        </div>
      </section>

      {/* ENHANCED CATEGORIES + GRID SECTION */}
      <section style={{ padding: "60px 0 120px" }}>
        <div className="container">
          <div style={{ 
            display: "flex", 
            justifyContent: "space-between", 
            alignItems: "flex-end",
            marginBottom: 40
          }}>
            <div>
              <h2 style={{ 
                margin: 0,
                fontSize: 36,
                fontWeight: 900,
                background: "linear-gradient(135deg, var(--text), var(--muted))",
                WebkitBackgroundClip: "text",
                letterSpacing: "-0.01em"
              }}>
                Explore by category
              </h2>
              <div className="muted" style={{ 
                marginTop: 8,
                fontSize: 16,
                display: "flex",
                alignItems: "center",
                gap: 8
              }}>
                <span>Found {products.length} items</span>
                {activeCategory && (
                  <div className="badge" style={{
                    background: "linear-gradient(135deg, var(--brand), var(--brand-2))",
                    color: "#fff",
                    fontWeight: 600
                  }}>
                    {activeCategory}
                  </div>
                )}
              </div>
            </div>

            <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
              <div className="chips" role="tablist" aria-label="Categories">
                <button
                  className={`chip ${activeCategory === null ? "active" : ""}`}
                  onClick={() => chooseCategory(null)}
                  style={{
                    background: activeCategory === null 
                      ? "linear-gradient(135deg, var(--brand), var(--brand-2))"
                      : "var(--surface)",
                    color: activeCategory === null ? "#fff" : "var(--text)",
                    fontWeight: activeCategory === null ? 700 : 600,
                    padding: "12px 20px",
                    fontSize: 15,
                    transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                    boxShadow: activeCategory === null ? "0 4px 16px rgba(var(--brand-rgb), 0.3)" : "none"
                  }}
                >All</button>

                {categories.map((c) => (
                  <button
                    key={c}
                    className={`chip ${activeCategory === c ? "active" : ""}`}
                    onClick={() => chooseCategory(c)}
                    style={{
                      background: activeCategory === c 
                        ? "linear-gradient(135deg, var(--brand), var(--brand-2))"
                        : "var(--surface)",
                      color: activeCategory === c ? "#fff" : "var(--text)",
                      fontWeight: activeCategory === c ? 700 : 600,
                      padding: "12px 20px",
                      fontSize: 15,
                      transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                      boxShadow: activeCategory === c ? "0 4px 16px rgba(var(--brand-rgb), 0.3)" : "none"
                    }}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div style={{ position: "relative" }}>
            {loading && (
              <div style={{ 
                padding: 80,
                textAlign: "center",
                background: "linear-gradient(135deg, rgba(var(--brand-rgb), 0.02), rgba(var(--brand-2-rgb), 0.02))",
                borderRadius: 24,
                border: "1px solid var(--border)"
              }}>
                <div style={{
                  width: 48,
                  height: 48,
                  border: "3px solid var(--border)",
                  borderTop: "3px solid var(--brand)",
                  borderRadius: "50%",
                  animation: "spin 1s linear infinite",
                  margin: "0 auto 16px"
                }} />
                <div className="muted" style={{ fontSize: 16, fontWeight: 500 }}>
                  Loading products…
                </div>
              </div>
            )}
            
            {error && (
              <div className="msg error" style={{
                background: "linear-gradient(135deg, rgba(239, 68, 68, 0.05), rgba(220, 38, 38, 0.02))",
                border: "1px solid rgba(239, 68, 68, 0.2)",
                borderRadius: 16,
                padding: "20px 24px",
                color: "#dc2626",
                fontWeight: 500
              }}>
                {error}
              </div>
            )}
            
            {!loading && !error && products.length === 0 && (
              <EmptyState 
                title="No products yet" 
                subtitle="We couldn't find products for this category." 
                cta={{ label: "See all", onClick: () => chooseCategory(null) }} 
              />
            )}

            {!loading && !error && products.length > 0 && (
              <div className="product-grid" style={{ 
                marginTop: 24,
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
                gap: 24,
                animation: "fadeInUp 0.6s cubic-bezier(0.4, 0, 0.2, 1) both"
              }}>
                {products.map((p, idx) => (
                  <div 
                    key={p.id} 
                    style={{ 
                      animation: `fadeInUp 0.6s cubic-bezier(0.4, 0, 0.2, 1) ${(idx % 8) * 50}ms both`,
                      transform: "translateY(20px)",
                      opacity: 0
                    }}
                  >
                    <div style={{ 
                      position: "relative",
                      background: "var(--surface)",
                      borderRadius: 20,
                      overflow: "hidden",
                      boxShadow: "0 4px 24px rgba(0,0,0,0.04)",
                      border: "1px solid var(--border)",
                      transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                      height: "100%"
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = "translateY(-8px)";
                      e.currentTarget.style.boxShadow = "0 20px 40px rgba(0,0,0,0.12)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = "translateY(0)";
                      e.currentTarget.style.boxShadow = "0 4px 24px rgba(0,0,0,0.04)";
                    }}
                    >
                      <ProductCard
                        product={p}
                        onView={viewProduct}
                        onAddToCart={() => quickAdd(p)}
                      />
                      
                      {/* Enhanced wishlist heart */}
                      <button
                        onClick={() => toggleWishlist(p.id)}
                        aria-label={wishlist.includes(p.id) ? "Remove from wishlist" : "Add to wishlist"}
                        style={{
                          position: "absolute",
                          right: 16,
                          top: 16,
                          background: wishlist.includes(p.id) 
                            ? "linear-gradient(135deg, #ff6b6b, #ee5a24)"
                            : "rgba(255,255,255,0.95)",
                          backdropFilter: "blur(10px)",
                          border: "none",
                          padding: 12,
                          borderRadius: 12,
                          boxShadow: "0 8px 24px rgba(0,0,0,0.1)",
                          cursor: "pointer",
                          transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                          transform: "scale(1)",
                          zIndex: 10
                        }}
                        onMouseEnter={(e) => {
                          e.target.style.transform = "scale(1.1)";
                          e.target.style.boxShadow = "0 12px 32px rgba(0,0,0,0.15)";
                        }}
                        onMouseLeave={(e) => {
                          e.target.style.transform = "scale(1)";
                          e.target.style.boxShadow = "0 8px 24px rgba(0,0,0,0.1)";
                        }}
                        title={wishlist.includes(p.id) ? "Saved to wishlist" : "Add to wishlist"}
                      >
                        <svg 
                          width="18" 
                          height="18" 
                          viewBox="0 0 24 24" 
                          fill={wishlist.includes(p.id) ? "#fff" : "none"} 
                          stroke={wishlist.includes(p.id) ? "none" : "var(--muted)"} 
                          strokeWidth="1.8"
                        >
                          <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                        </svg>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Add keyframe animations */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes fadeInUp {
          from { 
            opacity: 0; 
            transform: translateY(30px); 
          }
          to { 
            opacity: 1; 
            transform: translateY(0); 
          }
        }
        
        @keyframes slideInLeft {
          from { 
            opacity: 0; 
            transform: translateX(-50px); 
          }
          to { 
            opacity: 1; 
            transform: translateX(0); 
          }
        }
        
        @keyframes slideInRight {
          from { 
            opacity: 0; 
            transform: translateX(50px); 
          }
          to { 
            opacity: 1; 
            transform: translateX(0); 
          }
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          33% { transform: translateY(-20px) rotate(2deg); }
          66% { transform: translateY(-10px) rotate(-1deg); }
        }
        
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.8; transform: scale(1.1); }
        }
        
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        
        .product-grid > div {
          animation-fill-mode: both;
        }
      `}</style>
    </div>
  );
}

/* ---------- Enhanced Promo Card Component ---------- */

function PromoCard({ title, subtitle, icon, gradient }) {
  return (
    <div 
      style={{
        display: "flex",
        gap: 16,
        alignItems: "center",
        background: "var(--surface)",
        padding: 24,
        borderRadius: 20,
        boxShadow: "0 8px 32px rgba(0,0,0,0.06)",
        border: "1px solid var(--border)",
        transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
        position: "relative",
        overflow: "hidden"
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = "translateY(-4px)";
        e.currentTarget.style.boxShadow = "0 16px 48px rgba(0,0,0,0.1)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.boxShadow = "0 8px 32px rgba(0,0,0,0.06)";
      }}
    >
      {/* Background gradient overlay */}
      <div style={{
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: `${gradient}`,
        opacity: 0.02,
        zIndex: 0
      }} />

      <div style={{ 
        width: 64, 
        height: 64, 
        borderRadius: 16, 
        display: "flex", 
        alignItems: "center", 
        justifyContent: "center", 
        background: gradient,
        color: "#fff", 
        flexShrink: 0,
        position: "relative",
        zIndex: 1,
        boxShadow: "0 8px 24px rgba(0,0,0,0.15)"
      }}>
        {icon}
      </div>

      <div style={{ position: "relative", zIndex: 1 }}>
        <div style={{ 
          fontWeight: 800, 
          fontSize: 18,
          marginBottom: 4,
          color: "var(--text)"
        }}>
          {title}
        </div>
        <div className="muted" style={{ 
          fontSize: 15,
          lineHeight: 1.4,
          color: "var(--muted)"
        }}>
          {subtitle}
        </div>
      </div>
    </div>
  );
}
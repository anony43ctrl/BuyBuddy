import React, { useContext, useState, useEffect, useRef } from "react";
import { authService } from "../services/authService"; // Direct import from service
import { AuthContext } from "../context/AuthContext";

export default function LoginPage({ onLogin, onNavigate }) {
  const { setUser } = useContext(AuthContext);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const emailRef = useRef(null);

  useEffect(() => {
    emailRef.current && emailRef.current.focus();
  }, []);

  async function submit(e) {
    e && e.preventDefault();
    setError(null);
    if (!email || !password) {
      setError("Please enter email and password.");
      return;
    }
    setBusy(true);
    try {
      console.log("Attempting login with:", { email, password }); // Debug log
      const user = await authService.login({ email, password });
      console.log("Login successful:", user); // Debug log
      setUser(user);
      if (typeof onLogin === "function") onLogin();
    } catch (err) {
      console.error("Login error:", err); // Debug log
      setError(err?.message || "Login failed. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-page container" style={{ display: "flex", justifyContent: "center", paddingTop: 56 }}>
      <div className="auth-card" style={{ width: 520, padding: 28, borderRadius: 12, boxShadow: "0 8px 30px rgba(16,24,40,0.08)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 6 }}>
          <div style={{ width: 56, height: 56, background: "linear-gradient(135deg,#f97316,#ef4444)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 20 }}>
            OR
          </div>
          <div>
            <h2 style={{ margin: 0, fontSize: 20 }}>Welcome back</h2>
            <p className="muted" style={{ margin: 0, fontSize: 13 }}>Sign in to continue to your account</p>
          </div>
        </div>

        {error && <div className="msg error" style={{ marginTop: 12 }}>{error}</div>}

        <form onSubmit={submit} style={{ marginTop: 16 }}>
          <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Email</label>
          <input
            ref={emailRef}
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
            style={{ marginBottom: 12 }}
          />

          <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
            required
            style={{ marginBottom: 8 }}
          />

          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div style={{ fontSize: 13, color: "#666" }}>
              <label style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
                <input type="checkbox" disabled style={{ transform: "scale(0.95)" }} />
                Remember me
              </label>
            </div>
            <button className="btn btn-link" type="button" onClick={() => onNavigate("updatePassword")}>Forgot password?</button>
          </div>

          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-primary" style={{ flex: 1 }} disabled={busy}>
              {busy ? "Signing in…" : "Sign in"}
            </button>
            <button
              type="button"
              className="btn btn-outline"
              style={{ width: 140 }}
              onClick={() => onNavigate("register")}
            >
              Create account
            </button>
          </div>
        </form>

        <div style={{ marginTop: 18, textAlign: "center", fontSize: 13, color: "#666" }}>
          <span>Or continue with</span>
          <div style={{ marginTop: 10, display: "flex", justifyContent: "center", gap: 10 }}>
            <button className="btn" style={{ padding: "8px 12px" }} disabled>Google</button>
            <button className="btn" style={{ padding: "8px 12px" }} disabled>GitHub</button>
          </div>
        </div>
      </div>
    </div>
  );
}
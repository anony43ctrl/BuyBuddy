import React, { useContext, useState, useEffect, useRef } from "react";
import { authService } from "../services/authService";
import { AuthContext } from "../context/AuthContext";

export default function AdminLoginPage({ onLogin, onNavigate }) {
  const { setUser } = useContext(AuthContext);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const emailRef = useRef(null);

  useEffect(() => {
    emailRef.current && emailRef.current.focus();
  }, []);

  async function submit(e) {
    e && e.preventDefault();
    setError(null);
    setBusy(true);

    try {
      const user = await authService.loginAdmin({ email, password });
      setUser(user);
      onLogin();
    } catch (err) {
      setError(err?.message || "Admin login failed. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-page container" style={{ display: "flex", justifyContent: "center", paddingTop: 56 }}>
      <div className="auth-card" style={{ width: 520, padding: 28, borderRadius: 12, boxShadow: "0 8px 30px rgba(16,24,40,0.08)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 6 }}>
          <div style={{ width: 56, height: 56, background: "linear-gradient(135deg,#06b6d4,#0ea5e9)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 20 }}>
            A
          </div>
          <div>
            <h2 style={{ margin: 0, fontSize: 20 }}>Admin Login</h2>
            <p className="muted" style={{ margin: 0, fontSize: 13 }}>Sign in to access the admin dashboard</p>
          </div>
        </div>

        {error && <div className="msg error" style={{ marginTop: 12 }}>{error}</div>}

        <form onSubmit={submit} style={{ marginTop: 16 }}>
          <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Email</label>
          <input ref={emailRef} type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="admin@example.com" required style={{ marginBottom: 12 }} />

          <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Password</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" required style={{ marginBottom: 8 }} />

          <div style={{ display: "flex", justifyContent: "flex-end", alignItems: "center", marginBottom: 16 }}>
            <button className="btn btn-link" type="button" onClick={() => onNavigate("login")}>Customer login</button>
          </div>

          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-primary" type="submit" style={{ flex: 1 }} disabled={busy}>
              {busy ? "Signing in…" : "Sign in as Admin"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
import React, { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { userService } from "../services/userService";

export default function ProfilePage({ onNavigate }) {
  const { user, setUser, logout, token } = useContext(AuthContext);
  const [form, setForm] = useState({ fullname: "", phoneNumber: "", address: "" });
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);

  useEffect(() => {
    if (!user || !token) return;
    (async () => {
      try {
        const fresh = await userService.getUser(user.email, token);
        setForm({
          fullname: fresh.fullname || "",
          phoneNumber: fresh.phoneNumber || "",
          address: fresh.address || ""
        });
        setUser(fresh);
      } catch {
        // ignore
      }
    })();
  }, [user, token]);

  if (!user) return null;

  function avatarInitials(name) {
    if (!name) return (user.email || "U").slice(0, 1).toUpperCase();
    const parts = name.split(" ").filter(Boolean);
    if (parts.length === 1) return parts[0].slice(0, 1).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }

  async function handleSave(e) {
    e?.preventDefault();
    setBusy(true);
    setMsg(null);
    try {
      const payload = {
        fullname: form.fullname,
        phoneNumber: form.phoneNumber,
        address: form.address
      };
      const updated = await userService.updateUser(user.email, payload, token);
      setUser(updated);
      setMsg({ type: "success", text: "Profile saved" });
    } catch (err) {
      setMsg({ type: "error", text: err?.message || "Failed to save" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container" style={{ paddingTop: 20 }}>
      <div style={{ display: "flex", gap: 20, alignItems: "flex-start", marginBottom: 16 }}>
        <div style={{ width: 110, height: 110, borderRadius: 16, background: "linear-gradient(135deg,#f97316,#ef4444)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 36, fontWeight: 800 }}>
          {avatarInitials(form.fullname || user.fullname)}
        </div>

        <div style={{ flex: 1 }}>
          <h1 style={{ marginBottom: 6 }}>{form.fullname || user.fullname}</h1>
          <div style={{ color: "#666", marginBottom: 8 }}>{user.email}</div>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-outline" onClick={() => onNavigate("updatePassword")}>Change password</button>
            <button className="btn btn-outline" onClick={() => onNavigate("orders")}>Order History</button>
            <button className="btn" onClick={() => { logout(); onNavigate("home"); }}>Logout</button>
          </div>
        </div>
      </div>
      
      <div className="auth-card" style={{ padding: 20, borderRadius: 10 }}>
        {msg && <div className={`msg ${msg.type === "error" ? "error" : "success"}`}>{msg.text}</div>}

        <form onSubmit={handleSave} style={{ display: "grid", gap: 12 }}>
          <div>
            <label style={{ fontWeight: 700, display: "block", marginBottom: 6 }}>Full name</label>
            <input value={form.fullname} onChange={(e) => setForm({ ...form, fullname: e.target.value })} />
          </div>

          <div>
            <label style={{ fontWeight: 700, display: "block", marginBottom: 6 }}>Email</label>
            <input value={user.email} disabled />
          </div>

          <div>
            <label style={{ fontWeight: 700, display: "block", marginBottom: 6 }}>Phone</label>
            <input value={form.phoneNumber} onChange={(e) => setForm({ ...form, phoneNumber: e.target.value })} />
          </div>

          <div>
            <label style={{ fontWeight: 700, display: "block", marginBottom: 6 }}>Address</label>
            <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
          </div>

          <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
            <button className="btn btn-primary" disabled={busy} style={{ flex: 1 }}>
              {busy ? "Saving…" : "Save changes"}
            </button>
            <button type="button" className="btn btn-outline" onClick={() => setForm({ fullname: user.fullname, phoneNumber: user.phoneNumber || "", address: user.address || "" })}>
              Reset
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
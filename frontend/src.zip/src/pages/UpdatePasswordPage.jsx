import React, { useContext, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { userService } from "../services/userService";

export default function UpdatePasswordPage({ onNavigate }) {
  const { user, logout, token } = useContext(AuthContext);
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);

  if (!user) {
    onNavigate("login");
    return null;
  }

  function passwordStrength(p) {
    if (!p) return "too short";
    if (p.length < 6) return "weak";
    const score = [/[0-9]/, /[A-Z]/, /[a-z]/, /[^A-Za-z0-9]/].reduce((s, r) => s + (r.test(p) ? 1 : 0), 0);
    if (score >= 3 && p.length >= 8) return "strong";
    if (score >= 2) return "medium";
    return "weak";
  }

  async function submit(e) {
    e && e.preventDefault();
    setMsg(null);
    if (!oldPassword || !newPassword) {
      setMsg({ type: "error", text: "Please fill both fields" });
      return;
    }
    if (newPassword !== confirm) {
      setMsg({ type: "error", text: "New password and confirmation do not match" });
      return;
    }
    if (newPassword.length < 6) {
      setMsg({ type: "error", text: "New password must be at least 6 characters" });
      return;
    }

    setBusy(true);
    try {
      await userService.updatePassword(user.email, { oldPassword, newPassword }, token);
      setMsg({ type: "success", text: "Password updated. Please sign in again." });
      logout();
      setTimeout(() => onNavigate("login"), 1100);
    } catch (err) {
      setMsg({ type: "error", text: err?.message || "Failed to update password" });
    } finally {
      setBusy(false);
    }
  }

  const strength = passwordStrength(newPassword);
  const strengthColor = strength === "strong" ? "#16a34a" : strength === "medium" ? "#f59e0b" : "#ef4444";

  return (
    <div className="container" style={{ paddingTop: 36 }}>
      <div style={{ maxWidth: 640, margin: "0 auto" }}>
        <h1>Change password</h1>
        <p className="muted">For your security, we'll sign you out after a successful password change.</p>

        {msg && <div className={`msg ${msg.type === "error" ? "error" : "success"}`} style={{ marginTop: 12 }}>{msg.text}</div>}

        <form onSubmit={submit} className="auth-card" style={{ padding: 20, marginTop: 12 }}>
          <label style={{ fontWeight: 700 }}>Current password</label>
          <input type="password" value={oldPassword} onChange={(e) => setOldPassword(e.target.value)} required />

          <label style={{ fontWeight: 700 }}>New password</label>
          <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
          <div style={{ marginTop: 8, marginBottom: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ fontSize: 13, color: "#666" }}>Strength: <strong style={{ color: strengthColor }}>{strength}</strong></div>
            <div style={{ fontSize: 12, color: "#888" }}>Min 6 characters</div>
          </div>

          <label style={{ fontWeight: 700 }}>Confirm new password</label>
          <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required />

          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <button className="btn btn-primary" type="submit" style={{ flex: 1 }} disabled={busy}>
              {busy ? "Updating…" : "Update password"}
            </button>
            <button type="button" className="btn btn-outline" onClick={() => onNavigate("profile")}>Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
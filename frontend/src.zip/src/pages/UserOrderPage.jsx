import React, { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { orderService } from "../services/orderService";
import Toast from "../components/Toast";

export default function UserOrdersPage({ onNavigate }) {
  const { user } = useContext(AuthContext);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [toast, setToast] = useState(null);

  useEffect(() => {
    async function fetchOrders() {
      if (!user?.id) {
        setError("User not found");
        setLoading(false);
        return;
      }
      
      try {
        setLoading(true);
        const data = await orderService.getOrders(user.id);
        console.log("Orders data:", data); // Debug
        setOrders(Array.isArray(data) ? data : []);
        setError("");
      } catch (err) {
        console.error("Failed to load orders:", err);
        setError(err?.message || "Failed to load orders");
        setToast({ type: "error", title: "Error", text: "Failed to load your orders" });
      } finally {
        setLoading(false);
      }
    }

    if (user?.id) {
      fetchOrders();
    }
  }, [user]);

  const getStatusColor = (status) => {
    if (!status) return "#6b7280";
    
    switch (status.toUpperCase()) {
      case "DELIVERED":
        return "#10b981";
      case "PROCESSING":
        return "#f59e0b";
      case "SHIPPED":
        return "#3b82f6";
      case "CANCELLED":
        return "#ef4444";
      case "PENDING":
      default:
        return "#6b7280";
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return "Invalid Date";
    }
  };

  if (!user) {
    return (
      <div className="container" style={{ paddingTop: 20 }}>
        <div className="msg error" style={{ textAlign: "center", padding: 40 }}>
          <h3>Please Sign In</h3>
          <p>You need to be signed in to view your orders.</p>
          <button 
            className="btn btn-primary" 
            onClick={() => onNavigate("login")}
            style={{ marginTop: 16 }}
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container" style={{ paddingTop: 20, minHeight: "60vh" }}>
      <Toast msg={toast} onClose={() => setToast(null)} />
      
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <h1 style={{ margin: 0 }}>Your Order History</h1>
        <button 
          className="btn btn-outline" 
          onClick={() => onNavigate("products")}
        >
          Continue Shopping
        </button>
      </div>

      {loading ? (
        <div style={{ textAlign: "center", padding: 60 }}>
          <div style={{ 
            width: 40, 
            height: 40, 
            border: "3px solid #f3f4f6", 
            borderTop: "3px solid #3b82f6", 
            borderRadius: "50%", 
            animation: "spin 1s linear infinite",
            margin: "0 auto 16px"
          }} />
          <p style={{ color: "#6b7280" }}>Loading your orders...</p>
        </div>
      ) : error ? (
        <div className="msg error" style={{ textAlign: "center", padding: 40 }}>
          <h3 style={{ marginBottom: 8 }}>Unable to Load Orders</h3>
          <p style={{ marginBottom: 16 }}>{error}</p>
          <button 
            className="btn btn-primary" 
            onClick={() => window.location.reload()}
          >
            Try Again
          </button>
        </div>
      ) : orders.length === 0 ? (
        <div style={{ 
          textAlign: "center", 
          padding: "80px 20px", 
          background: "#f8fafc", 
          borderRadius: 12,
          border: "1px solid #e2e8f0"
        }}>
          <div style={{ fontSize: 64, marginBottom: 16 }}>📦</div>
          <h3 style={{ marginBottom: 8, color: "#374151" }}>No Orders Yet</h3>
          <p style={{ color: "#6b7280", marginBottom: 24 }}>
            You haven't placed any orders yet. Start shopping to see your orders here!
          </p>
          <button 
            className="btn btn-primary" 
            onClick={() => onNavigate("products")}
          >
            Start Shopping
          </button>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          {orders.map((order) => (
            <div 
              key={order.id} 
              style={{ 
                border: "1px solid #e5e7eb", 
                borderRadius: 12, 
                overflow: "hidden",
                background: "#fff",
                boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
              }}
            >
              {/* Order Header */}
              <div style={{ 
                padding: "20px", 
                background: "#f8fafc", 
                borderBottom: "1px solid #e5e7eb",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                flexWrap: "wrap",
                gap: 12
              }}>
                <div>
                  <h3 style={{ margin: 0, fontSize: 18 }}>Order #{order.id}</h3>
                  <p style={{ margin: "4px 0 0 0", color: "#6b7280", fontSize: 14 }}>
                    Placed on {formatDate(order.orderDate)}
                  </p>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
                  <span 
                    style={{ 
                      background: getStatusColor(order.orderStatus),
                      color: "white",
                      padding: "6px 12px",
                      borderRadius: 20,
                      fontSize: 12,
                      fontWeight: 600,
                      textTransform: "uppercase"
                    }}
                  >
                    {order.orderStatus || "PENDING"}
                  </span>
                  <span style={{ fontWeight: 700, fontSize: 18 }}>
                    ₹{(order.totalAmount || 0).toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Order Items */}
              <div style={{ padding: "20px" }}>
                <h4 style={{ margin: "0 0 16px 0", fontSize: 16 }}>Items</h4>
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                  {(order.items || []).map((item, index) => (
                    <div 
                      key={index} 
                      style={{ 
                        display: "flex", 
                        alignItems: "center", 
                        gap: 12,
                        padding: "12px",
                        background: "#fafafa",
                        borderRadius: 8
                      }}
                    >
                      <div style={{ width: 60, height: 60, background: "#e5e7eb", borderRadius: 6, flexShrink: 0 }}>
                        {item.product?.imageURL && (
                          <img 
                            src={item.product.imageURL} 
                            alt={item.product?.name}
                            style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: 6 }}
                          />
                        )}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 600, marginBottom: 4 }}>
                          {item.product?.name || `Product ${item.productId}`}
                        </div>
                        <div style={{ color: "#6b7280", fontSize: 14 }}>
                          Quantity: {item.quantity} × ₹{(item.price || 0).toFixed(2)}
                        </div>
                      </div>
                      <div style={{ fontWeight: 700 }}>
                        ₹{((item.price || 0) * (item.quantity || 1)).toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Order Footer */}
              <div style={{ 
                padding: "16px 20px", 
                background: "#f8fafc", 
                borderTop: "1px solid #e5e7eb",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                flexWrap: "wrap",
                gap: 12
              }}>
                <div style={{ fontSize: 14, color: "#6b7280" }}>
                  {order.shippingAddress && (
                    <div>
                      <strong>Shipping to:</strong> {order.shippingAddress}
                    </div>
                  )}
                  {order.paymentMethod && (
                    <div style={{ marginTop: 4 }}>
                      <strong>Payment:</strong> {order.paymentMethod} 
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <style>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
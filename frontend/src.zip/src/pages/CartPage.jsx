import React, { useContext, useEffect, useState } from "react";
import { cartService } from "../services/cartService";
import { productService } from "../services/productService";
import { AuthContext } from "../context/AuthContext";
import CartItem from "../components/CartItem";
import Toast from "../components/Toast";

export default function CartPage({ onNavigate }) {
  const { user, token } = useContext(AuthContext);
  const [cart, setCart] = useState(null);
  const [productsById, setProductsById] = useState({});
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    if (!user || !user.id) {
      onNavigate("login");
      return;
    }
    loadCart();
  }, [user]);

  async function loadCart() {
    if (!user || !user.id) return;
    setLoading(true);
    try {
      const c = await cartService.getCart(user.id);
      console.log("Cart data:", c); // Debug
      setCart(c);
      
      // Load product details for items in cart
      if (c && c.items) {
        const productIds = [...new Set(c.items.map(item => item.productId))];
        const productPromises = productIds.map(id => 
          productService.getProduct(id).catch(() => null)
        );
        const products = await Promise.all(productPromises);
        
        const map = {};
        products.forEach((p) => {
          if (p) map[p.id] = p;
        });
        setProductsById(map);
      }
    } catch (e) {
      console.error("Cart load error:", e);
      setToast({ type: "error", title: "Cart error", text: e.message || "Failed to load cart." });
    } finally {
      setLoading(false);
    }
  }

  async function handleUpdateQty(productId, qty) {
    if (!user || !user.id) return;
    
    const backup = cart;
    try {
      // Optimistic update
      const newCart = {
        ...cart,
        items: (cart.items || []).map((it) =>
          it.productId === productId ? { ...it, quantity: qty } : it
        ),
      };
      setCart(newCart);
      
      await cartService.updateCartItem(user.id, productId, qty);
      setToast({ type: "success", title: "Updated", text: "Quantity updated." });
    } catch (e) {
      setToast({ type: "error", title: "Failed", text: e.message || "Could not update quantity." });
      setCart(backup);
    }
  }

  async function handleRemove(productId) {
    if (!productId || !user || !user.id) {
      setToast({ type: "error", text: "Invalid request." });
      return;
    }
    try {
      setLoading(true);
      await cartService.removeCartItem(user.id, productId);
      await loadCart(); // Reload cart to get fresh data
      setToast({ type: "success", text: "Item removed." });
    } catch (e) {
      setToast({ type: "error", text: e.message || "Remove failed." });
    } finally {
      setLoading(false);
    }
  }

  async function handleCheckout() {
    if (!user || !user.id) {
      setToast({ type: "error", text: "Please sign in to checkout." });
      onNavigate("login");
      return;
    }

    try {
      setLoading(true);
      setToast({ type: "info", title: "Processing", text: "Placing your order..." });
      
      const order = await cartService.checkoutCart(user.id);
      
      setToast({
        type: "success",
        title: "Order placed!",
        text: `Order #${order.id} placed successfully!`,
      });

      // Reload cart (should be empty after checkout)
      await loadCart();
      
      // Navigate to orders page after delay
      setTimeout(() => onNavigate("orders"), 2000);
    } catch (e) {
      console.error("Checkout error:", e);
      setToast({
        type: "error",
        title: "Checkout failed",
        text: e.message || "Could not place order. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  }

  const items = (cart && cart.items) || [];
  const subtotal = items.reduce((s, it) => {
    const product = productsById[it.productId];
    const price = product?.price || it.price || 0;
    const quantity = it.quantity || 1;
    return s + (price * quantity);
  }, 0);
  
  const shippingFee = subtotal > 0 ? 49.0 : 0.0;
  const tax = +(subtotal * 0.05).toFixed(2);
  const total = +(subtotal + shippingFee + tax).toFixed(2);

  return (
    <div className="container" style={{ marginTop: 12, padding: "20px 0" }}>
      <Toast msg={toast} onClose={() => setToast(null)} />
      <h1>Your cart</h1>
      
      {loading && <p>Loading…</p>}
      
      {!loading && items.length === 0 && (
        <div style={{ textAlign: "center", padding: "40px 0" }}>
          <p style={{ fontSize: 18, color: "#666", marginBottom: 20 }}>Your cart is empty.</p>
          <button className="btn btn-primary" onClick={() => onNavigate("products")}>
            Start shopping
          </button>
        </div>
      )}

      {items.length > 0 && (
        <div style={{ display: "grid", gridTemplateColumns: "2fr 360px", gap: 20 }}>
          <div>
            {items.map((it, index) => {
              const product = productsById[it.productId];
              return (
                <CartItem
                  key={`${it.productId}-${index}`}
                  item={it}
                  product={product}
                  onUpdateQty={handleUpdateQty}
                  onRemove={handleRemove}
                />
              );
            })}
          </div>

          <aside style={{ position: "sticky", top: 84 }}>
            <div style={{ 
              background: "#fff", 
              padding: 18, 
              borderRadius: 10, 
              boxShadow: "0 6px 20px rgba(16,24,40,0.06)" 
            }}>
              <h3 style={{ marginBottom: 16 }}>Order Summary</h3>
              
              <div style={{ marginBottom: 20 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <span>Subtotal</span>
                  <span>₹{subtotal.toFixed(2)}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <span>Shipping</span>
                  <span>₹{shippingFee.toFixed(2)}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <span>Tax (5%)</span>
                  <span>₹{tax.toFixed(2)}</span>
                </div>
                <div style={{ height: 1, background: "#f1f1f1", margin: "12px 0" }} />
                <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 800, fontSize: 18 }}>
                  <span>Total</span>
                  <span>₹{total.toFixed(2)}</span>
                </div>
              </div>

              <div style={{ marginTop: 20 }}>
                <button 
                  className="btn btn-primary" 
                  style={{ width: "100%", padding: 12 }} 
                  onClick={handleCheckout}
                  disabled={loading}
                >
                  {loading ? "Processing..." : "Proceed to checkout"}
                </button>
                <button
                  className="btn btn-outline"
                  style={{ width: "100%", marginTop: 10, padding: 12 }}
                  onClick={() => onNavigate("products")}
                >
                  Continue shopping
                </button>
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
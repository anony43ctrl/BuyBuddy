import React, { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { orderService } from "../services/orderService";
import Toast from "../components/Toast";

export default function OrdersPage({ onNavigate }) {
  const { user, token } = useContext(AuthContext);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    if (!user || !user.id) {
      onNavigate("login");
      return;
    }
    loadOrders();
  }, [user, token]);

  async function loadOrders() {
    setLoading(true);
    try {
      const data = await orderService.getOrders(user.id, token);
      setOrders(data || []);
    } catch (e) {
      setToast({ type: "error", text: e.message || "Failed to load orders." });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container" style={{ marginTop: 20 }}>
      <Toast msg={toast} onClose={() => setToast(null)} />
      <h1>Your Orders</h1>
      {loading && <p>Loading…</p>}
      {!loading && orders.length === 0 && <p>You haven't placed any orders yet.</p>}
      {!loading && orders.length > 0 && (
        <div style={{ display: "grid", gap: 16 }}>
          {orders.map((order) => (
            <div key={order.id} style={{ border: "1px solid #eee", padding: 16, borderRadius: 8 }}>
              <h3>Order #{order.id}</h3>
              <p><strong>Date:</strong> {new Date(order.createdAt).toLocaleString()}</p>
              <p><strong>Status:</strong> {order.status}</p>
              <p><strong>Total:</strong> ₹{order.total}</p>
              <ul>
                {order.items.map((item, i) => (
                  <li key={i}>
                    {item.productName} × {item.quantity} = ₹{item.price * item.quantity}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
import React, { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { userService } from "../services/userService";
import Toast from "../components/Toast";

export default function AdminUsersPage() {
  const { token, user } = useContext(AuthContext);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    if (!user || user.role !== "ADMIN") {
      setError("Admin access required");
      setLoading(false);
      return;
    }
    loadUsers();
  }, [user, token]);

  // Note: Since there's no dedicated admin users endpoint in your backend,
  // this is a placeholder implementation
  async function loadUsers() {
    setLoading(true);
    try {
      // This would typically call an admin endpoint like:
      // const users = await userService.adminGetAllUsers(token);
      // For now, we'll simulate with empty data
      setUsers([]);
      setToast({ type: "info", title: "Info", text: "User management API not implemented yet" });
    } catch (err) {
      setError(err?.message || "Failed to load users");
      setToast({ type: "error", title: "Error", text: "Failed to load users" });
    } finally {
      setLoading(false);
    }
  }

  async function handleToggleUserStatus(userId, currentStatus) {
    try {
      // This would typically call an admin endpoint like:
      // await userService.adminUpdateUserStatus(userId, !currentStatus, token);
      setToast({ 
        type: "success", 
        title: "User Updated", 
        text: `User status updated successfully` 
      });
      // Reload users after update
      await loadUsers();
    } catch (err) {
      setToast({ 
        type: "error", 
        title: "Update Failed", 
        text: err?.message || "Failed to update user status" 
      });
    }
  }

  if (!user || user.role !== "ADMIN") {
    return (
      <div className="container" style={{ paddingTop: 20 }}>
        <div className="msg error">Access denied. Admin privileges required.</div>
      </div>
    );
  }

  return (
    <div className="container" style={{ paddingTop: 20 }}>
      <Toast msg={toast} onClose={() => setToast(null)} />
      
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <h1 style={{ margin: 0 }}>Manage Users</h1>
        <div style={{ display: "flex", gap: 12 }}>
          <button className="btn btn-primary" onClick={loadUsers} disabled={loading}>
            {loading ? "Refreshing..." : "Refresh"}
          </button>
        </div>
      </div>

      {error && (
        <div className="msg error" style={{ marginBottom: 16 }}>
          {error}
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: "center", padding: 40 }}>
          <div style={{ 
            width: 40, 
            height: 40, 
            border: "3px solid #f3f4f6", 
            borderTop: "3px solid #3b82f6", 
            borderRadius: "50%", 
            animation: "spin 1s linear infinite",
            margin: "0 auto 16px"
          }} />
          <p>Loading users...</p>
        </div>
      ) : users.length === 0 ? (
        <div style={{ 
          textAlign: "center", 
          padding: "60px 20px", 
          background: "#f8fafc", 
          borderRadius: 12,
          border: "1px solid #e2e8f0"
        }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>👥</div>
          <h3 style={{ marginBottom: 8, color: "#374151" }}>No Users Found</h3>
          <p style={{ color: "#6b7280", marginBottom: 24 }}>
            User management functionality is not yet implemented in the backend.
          </p>
          <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
            <button className="btn btn-primary" onClick={loadUsers}>
              Check Again
            </button>
            <button className="btn btn-outline" onClick={() => window.location.reload()}>
              Reload Page
            </button>
          </div>
        </div>
      ) : (
        <div style={{ background: "#fff", borderRadius: 12, overflow: "hidden", boxShadow: "0 1px 3px rgba(0,0,0,0.1)" }}>
          <table className="table" style={{ margin: 0 }}>
            <thead>
              <tr style={{ background: "#f8fafc" }}>
                <th style={{ padding: "16px", textAlign: "left", fontWeight: 600 }}>ID</th>
                <th style={{ padding: "16px", textAlign: "left", fontWeight: 600 }}>Name</th>
                <th style={{ padding: "16px", textAlign: "left", fontWeight: 600 }}>Email</th>
                <th style={{ padding: "16px", textAlign: "left", fontWeight: 600 }}>Role</th>
                <th style={{ padding: "16px", textAlign: "left", fontWeight: 600 }}>Phone</th>
                <th style={{ padding: "16px", textAlign: "left", fontWeight: 600 }}>Status</th>
                <th style={{ padding: "16px", textAlign: "left", fontWeight: 600 }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id} style={{ borderBottom: "1px solid #e5e7eb" }}>
                  <td style={{ padding: "16px" }}>{user.id}</td>
                  <td style={{ padding: "16px" }}>
                    <div style={{ fontWeight: 500 }}>{user.fullname || "N/A"}</div>
                  </td>
                  <td style={{ padding: "16px" }}>{user.email}</td>
                  <td style={{ padding: "16px" }}>
                    <span 
                      className={`badge ${user.role === "ADMIN" ? "badge-primary" : "badge-secondary"}`}
                      style={{ 
                        background: user.role === "ADMIN" ? "#dc2626" : "#6b7280",
                        color: "white",
                        padding: "4px 8px",
                        borderRadius: 4,
                        fontSize: 12,
                        fontWeight: 600
                      }}
                    >
                      {user.role}
                    </span>
                  </td>
                  <td style={{ padding: "16px" }}>{user.phoneNumber || "N/A"}</td>
                  <td style={{ padding: "16px" }}>
                    <span 
                      className={`badge ${user.active ? "badge-success" : "badge-error"}`}
                      style={{ 
                        background: user.active ? "#16a34a" : "#6b7280",
                        color: "white",
                        padding: "4px 8px",
                        borderRadius: 4,
                        fontSize: 12,
                        fontWeight: 600
                      }}
                    >
                      {user.active ? "Active" : "Inactive"}
                    </span>
                  </td>
                  <td style={{ padding: "16px" }}>
                    <div style={{ display: "flex", gap: 8 }}>
                      <button 
                        className="btn btn-outline" 
                        onClick={() => handleToggleUserStatus(user.id, user.active)}
                        style={{ padding: "6px 12px", fontSize: 12 }}
                      >
                        {user.active ? "Deactivate" : "Activate"}
                      </button>
                      <button 
                        className="btn btn-danger" 
                        onClick={() => {
                          if (confirm(`Are you sure you want to delete user ${user.email}?`)) {
                            // Handle delete
                          }
                        }}
                        style={{ padding: "6px 12px", fontSize: 12 }}
                        disabled={user.role === "ADMIN"}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <style jsx>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
import React, { useContext, useEffect, useState } from "react";
import { productService } from "../services/productService";
import { orderService } from "../services/orderService";
import { AuthContext } from "../context/AuthContext";
import Toast from "../components/Toast";

export default function AdminDashboardPage({ onNavigate }) {
  const { token, user } = useContext(AuthContext);
  const [productsCount, setProductsCount] = useState(0);
  const [ordersCount, setOrdersCount] = useState(0);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    let mounted = true;

    async function load() {
      try {
        const prods = await productService.adminGetAllProducts(token);
        if (mounted) setProductsCount(prods.length || 0);
      } catch (err) {
        console.error("load products failed", err);
        setToast({ type: "error", title: "Products", text: "Failed to load products" });
      }

      try {
        const orders = await orderService.getOrders(null, token);
        if (mounted) setOrdersCount(orders.length || 0);
      } catch (err) {
        console.error("load orders failed", err);
        setToast({ type: "error", title: "Orders", text: "Failed to load orders" });
      }
    }

    load();
    return () => {
      mounted = false;
    };
  }, [token]);

  return (
    <div className="container" style={{ paddingTop: 28 }}>
      <Toast msg={toast} onClose={() => setToast(null)} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h1 style={{ margin: 0 }}>Admin dashboard</h1>
          <div className="muted" style={{ marginTop: 6 }}>{user ? user.fullname || user.email : "Administrator"}</div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 18, marginTop: 24 }}>
        <div className="card">
          <h3 style={{ margin: 0 }}>Products</h3>
          <div style={{ marginTop: 12, fontSize: 28, fontWeight: 800 }}>{productsCount}</div>
          <div style={{ marginTop: 12 }}>
            <button className="btn" onClick={() => onNavigate?.("adminProducts")}>Manage products</button>
          </div>
        </div>

        <div className="card">
          <h3 style={{ margin: 0 }}>Orders</h3>
          <div style={{ marginTop: 12, fontSize: 28, fontWeight: 800 }}>{ordersCount}</div>
          <div style={{ marginTop: 12 }}>
            <button className="btn" onClick={() => onNavigate?.("adminOrders")}>Manage orders</button>
          </div>
        </div>

        <div className="card">
          <h3 style={{ margin: 0 }}>Users</h3>
          <div style={{ marginTop: 12, fontSize: 28, fontWeight: 800 }}>—</div>
          <div style={{ marginTop: 12 }}>
            <button className="btn btn-outline" onClick={() => alert("User management coming in next phase")}>Manage users</button>
          </div>
        </div>
      </div>
    </div>
  );
}
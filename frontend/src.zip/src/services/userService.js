import { API, getHeaders, handleResponse } from './apiConfig';

export const userService = {
  getUser: async (email, token) => {
    const response = await fetch(`${API}/api/v1/user/${encodeURIComponent(email)}`, {
      headers: getHeaders(token),
    });
    return handleResponse(response);
  },

  updateUser: async (email, payload, token) => {
    const response = await fetch(`${API}/api/v1/user/${encodeURIComponent(email)}/update`, {
      method: "PUT",
      headers: getHeaders(token),
      body: JSON.stringify(payload),
    });
    return handleResponse(response);
  },

  updatePassword: async (email, payload, token) => {
    const response = await fetch(`${API}/api/v1/user/${encodeURIComponent(email)}/password`, {
      method: "PUT",
      headers: getHeaders(token),
      body: JSON.stringify(payload),
    });
    return handleResponse(response);
  }
};
import { API, getHeaders, handleResponse } from './apiConfig';

export const authService = {
  register: async (payload) => {
    const response = await fetch(`${API}/api/v1/auth/register`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(payload),
    });
    return handleResponse(response);
  },

  login: async (payload) => {
    const response = await fetch(`${API}/api/v1/auth/login`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(payload),
    });
    return handleResponse(response);
  },

  loginAdmin: async (payload) => {
    const response = await fetch(`${API}/api/v1/auth/login`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(payload),
    });
    const user = await handleResponse(response);
    if (user.role !== "ADMIN") {
      throw new Error("You do not have administrative privileges.");
    }
    return user;
  }
};
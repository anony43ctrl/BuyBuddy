import { API, getHeaders, handleResponse } from './apiConfig';

export const orderService = {
  placeOrder: async (orderPayload) => {
    const response = await fetch(`${API}/api/v1/order/create`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(orderPayload),
    });
    return handleResponse(response);
  },

  getOrders: async (userId = null) => {
    const url = userId
      ? `${API}/api/v1/order/customer/${userId}`
      : `${API}/api/v1/order`;
    const response = await fetch(url);
    return handleResponse(response);
  },

  adminUpdateOrderStatus: async (orderId, status) => {
    const response = await fetch(`${API}/api/v1/order/${orderId}/status?orderStatus=${status}`, {
      method: "PUT",
    });
    return handleResponse(response);
  },

  cancelOrder: async (orderId) => {
    const response = await fetch(`${API}/api/v1/order/${orderId}`, {
      method: "DELETE",
    });
    return handleResponse(response);
  }
};
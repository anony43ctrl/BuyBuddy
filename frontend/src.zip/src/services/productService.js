import { API, getHeaders, handleResponse } from './apiConfig';

export const productService = {
  // Public product endpoints
  getProducts: async () => {
    const response = await fetch(`${API}/api/products`);
    return handleResponse(response);
  },

  getProduct: async (productId) => {
    const response = await fetch(`${API}/api/products/${productId}`);
    return handleResponse(response);
  },

  searchProducts: async (name) => {
    const response = await fetch(`${API}/api/products/search?name=${encodeURIComponent(name)}`);
    return handleResponse(response);
  },

  getProductsByCategory: async (category) => {
    const response = await fetch(`${API}/api/products/category/${encodeURIComponent(category)}`);
    return handleResponse(response);
  },

  // Admin product endpoints
  adminGetAllProducts: async () => {
    const response = await fetch(`${API}/api/admin/products`);
    return handleResponse(response);
  },

  adminGetProduct: async (productId) => {
    const response = await fetch(`${API}/api/admin/products/${productId}`);
    return handleResponse(response);
  },

  createProduct: async (payload) => {
    const response = await fetch(`${API}/api/admin/products`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(payload),
    });
    return handleResponse(response);
  },

  updateProduct: async (productId, payload) => {
    const response = await fetch(`${API}/api/admin/products/${productId}`, {
      method: "PUT",
      headers: getHeaders(),
      body: JSON.stringify(payload),
    });
    return handleResponse(response);
  },

  deleteProduct: async (productId) => {
    const response = await fetch(`${API}/api/admin/products/${productId}`, {
      method: "DELETE",
    });
    return handleResponse(response);
  },

  reactivateProduct: async (productId) => {
    const response = await fetch(`${API}/api/admin/products/${productId}/reactivate`, {
      method: "PUT",
    });
    return handleResponse(response);
  }
};
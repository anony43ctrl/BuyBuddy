import { API, getHeaders, handleResponse } from './apiConfig';

export const cartService = {
  getCart: async (userId) => {
    const response = await fetch(`${API}/api/v1/cart/${userId}`);
    return handleResponse(response);
  },

  addToCart: async (userId, productId, quantity = 1) => {
    const response = await fetch(`${API}/api/v1/cart/${userId}/add/${productId}?quantity=${quantity}`, {
      method: "POST",
    });
    return handleResponse(response);
  },

  updateCartItem: async (userId, productId, quantity = 1) => {
    const response = await fetch(`${API}/api/v1/cart/${userId}/update/${productId}?quantity=${quantity}`, {
      method: "PUT",
    });
    return handleResponse(response);
  },

  removeCartItem: async (userId, productId) => {
    const response = await fetch(`${API}/api/v1/cart/${userId}/remove/${productId}`, {
      method: "DELETE",
    });
    return handleResponse(response);
  },

  clearCart: async (userId) => {
    const response = await fetch(`${API}/api/v1/cart/${userId}/clear`, {
      method: "DELETE",
    });
    return handleResponse(response);
  },

  checkoutCart: async (userId) => {
    const response = await fetch(`${API}/api/v1/cart/${userId}/checkout`, {
      method: "POST",
    });
    return handleResponse(response);
  }
};
const API = import.meta.env.VITE_API_URL || "http://localhost:8090";

export { API };

export function getHeaders(token) {
  const headers = {
    "Content-Type": "application/json",
  };
  if (token) {
    headers["X-API-Key"] = token; // Your backend uses X-API-Key
  }
  return headers;
}

export async function handleResponse(response) {
  // Handle empty responses
  if (response.status === 204) {
    return null;
  }

  const contentType = response.headers.get("content-type") || "";
  let body = null;

  if (contentType.includes("application/json")) {
    try {
      body = await response.json();
    } catch (error) {
      throw new Error("Invalid JSON response from server");
    }
  } else {
    body = await response.text();
  }

  if (!response.ok) {
    // Extract error message from backend response
    const message = (body && (body.detail || body.message || body.error)) || body || response.statusText;
    const error = new Error(message);
    error.status = response.status;
    error.body = body;
    throw error;
  }

  return body;
}
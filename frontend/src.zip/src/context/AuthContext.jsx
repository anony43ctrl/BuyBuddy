import React, { createContext, useEffect, useState } from "react";

export const AuthContext = createContext({
  user: null,
  token: null,
  setUser: () => {},
  logout: () => {},
});

export function AuthProvider({ children }) {
  const [user, setUserState] = useState(() => {
    try {
      const s = localStorage.getItem("user");
      return s ? JSON.parse(s) : null;
    } catch {
      return null;
    }
  });
  
  const [token, setToken] = useState(() => {
    return localStorage.getItem("token") || null;
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem("user", JSON.stringify(user));
      // Store user email as token (backend uses X-API-Key === email)
      if (user.email) {
        setToken(user.email);
        localStorage.setItem("token", user.email);
      }
    } else {
      localStorage.removeItem("user");
      localStorage.removeItem("token");
      setToken(null);
    }
  }, [user]);

  function setUser(u) {
    setUserState(u || null);
  }

  function logout() {
    setUserState(null);
    setToken(null);
    localStorage.removeItem("user");
    localStorage.removeItem("token");
  }

  // Check if user is admin
  const isAdmin = user?.role === "ADMIN";

  return (
    <AuthContext.Provider value={{ 
      user, 
      token, 
      setUser, 
      logout,
      isAdmin 
    }}>
      {children}
    </AuthContext.Provider>
  );
}
export async function sendWelcomeNotification(email, phoneNumber, fullname) {
  try {
    const res = await fetch("http://localhost:5000/send-notification", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email, phoneNumber, fullname })
    });
 
    const data = await res.json();
    console.log("Notification sent:", data);
  } catch (err) {
    console.error("Notification error:", err);
  }
}